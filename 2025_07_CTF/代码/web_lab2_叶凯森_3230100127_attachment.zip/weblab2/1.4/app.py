from flask import Flask, render_template, request, redirect, url_for
import os
import time
app = Flask(__name__)

SECRET_VALUE = "AAA{Well_done!Here_is_Task_4_20_points_for_you!D81B3EB8-ABA4}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/victim')
def victim():
    if request.remote_addr != "127.0.0.1":
        return "You are not victim, only the victim can access this page.", 403
    # 关键：传递一个时间戳用于防止缓存
    return render_template('victim.html', secret=SECRET_VALUE, cache_buster=time.time())

@app.route('/inject', methods=['GET', 'POST'])
def inject_css():
    if request.method == 'POST':
        css_content = request.form.get('css', '')
        with open('static/custom.css', 'w') as f:
            f.write(css_content)
        return redirect(url_for('inject_css'))

    css_content = ""
    if os.path.exists('static/custom.css'):
        with open('static/custom.css', 'r') as f:
            css_content = f.read()

    return render_template('inject.html', css=css_content)

if __name__ == '__main__':
    if not os.path.exists('static'):
        os.makedirs('static')
    if not os.path.exists('static/custom.css'):
        with open('static/custom.css', 'w') as f:
            f.write('/* css injection */')

    app.run(host='0.0.0.0', port=5001)