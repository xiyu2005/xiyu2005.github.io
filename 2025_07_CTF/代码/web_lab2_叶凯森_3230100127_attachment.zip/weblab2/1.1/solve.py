import hashlib
from html.parser import HTMLParser
from collections import deque
import os

# Define a Node class to build our own tree structure
class Node:
    def __init__(self, tag, an_id):
        self.tag = tag
        self.id = an_id
        self.children = []

# Create a custom parser by inheriting from HTMLParser
class MyHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.root = None
        # stack is used to keep track of the current parent node
        self.stack = []

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)
        node_id = attrs_dict.get('id', '')
        new_node = Node(tag, node_id)

        # The first tag encountered is the root
        if self.root is None:
            self.root = new_node
        else:
            # If stack is not empty, the new node is a child of the last node in the stack
            if self.stack:
                self.stack[-1].children.append(new_node)
        
        # Push the new node to the stack, making it the current parent for subsequent nodes
        self.stack.append(new_node)

    def handle_endtag(self, tag):
        # When a tag ends, pop from the stack to go up the tree
        # We check if the closing tag matches the tag of the node on top of the stack
        # to handle malformed HTML correctly.
        if self.stack and self.stack[-1].tag == tag:
            self.stack.pop()

# --- Main Script ---

file_path = 'html_parser.html'

if not os.path.exists(file_path):
    print(f"错误：找不到文件 '{file_path}'。请确保文件已上传。")
else:
    # Step 1: Read the HTML file
    with open(file_path, 'r', encoding='utf-8') as f:
        html_content = f.read()

    # Step 2: Parse the HTML and build the tree
    parser = MyHTMLParser()
    parser.feed(html_content)
    root_node = parser.root

    # Step 3: Perform level-order (breadth-first) traversal on our custom tree
    s_parts = []
    if root_node:
        queue = deque([root_node])
        while queue:
            current_node = queue.popleft()
            
            # Format the string as "tag:id"
            s_parts.append(f"{current_node.tag}:{current_node.id}")
            
            # Add all children to the queue for the next level
            for child in current_node.children:
                queue.append(child)

    # Join the parts to form the final string 's'
    s = ",".join(s_parts)

    # Step 4: Calculate the MD5 hash of string 's'
    md5_hash = hashlib.md5(s.encode('utf-8')).hexdigest()

    # Step 5: Format the final output string
    final_flag = f"AAA{{{md5_hash}}}"

    # Print the intermediate and final results
    print(f"解析并遍历HTML后生成的字符串 s 为:\n{s}\n")
    print("成功生成了字符串 s 并计算了其 MD5 值。")
    print(f"最终的 flag 为:\n{final_flag}")