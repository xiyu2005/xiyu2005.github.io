# 假设我们已经有了上一部分生成的 MT 和 MT_inv

# 1. 随机设置一个 flag (长度为30的倍数)
my_flag = "flag{this_is_Asecret_sagemath}" # 恰好30个字符
print(f"原始 Flag: {my_flag}\n")

# 2. 将 flag 转换为明文矩阵 FT (3x10)
FT = matrix(Z256, 3, 10)
for i in range(3):
    for j in range(10):
        # 按列填充
        FT[i, j] = ord(my_flag[i + j * 3])

print("明文矩阵 FT:")
print(FT)

# 3. 使用 MT 加密 FT，得到密文矩阵 RT
RT = MT * FT
print("\n加密后的密文矩阵 RT:")
print(RT)

# 4. (核心) 使用 MT_inv 和 RT 来恢复 FT
FT_recovered = MT_inv * RT
print("\n使用逆矩阵恢复的明文矩阵 FT_recovered:")
print(FT_recovered)

# 5. 将恢复的矩阵 FT_recovered 转换回字符串，进行比对
recovered_flag = ""
for j in range(10):
    for i in range(3):
        recovered_flag += chr(int(FT_recovered[i, j]))

print(f"\n恢复的 Flag: {recovered_flag}\n")
assert my_flag == recovered_flag
print("比对成功！原始 Flag 与恢复的 Flag 完全一致。")