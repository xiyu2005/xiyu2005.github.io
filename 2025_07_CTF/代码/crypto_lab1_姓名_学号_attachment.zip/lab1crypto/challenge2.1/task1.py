# 定义在模256下的整数环
Z256 = Zmod(256)

# 随机生成一个 3x3 矩阵 MT
# 为了确保它可逆，我们循环生成，直到找到一个可逆的为止
while True:
    # 从Z256中随机选取9个元素，构成一个3x3矩阵
    MT = random_matrix(Z256, 3, 3)
    # is_invertible() 会检查 det(MT) 是否与 256 互质
    if MT.is_invertible():
        break

# 求 MT 的逆矩阵
MT_inv = MT.inverse()

# 打印结果
print("随机生成的矩阵 MT:")
print(MT)
print("\nMT 的行列式 :")
print(MT.det())
print("\nMT 的逆矩阵 MT_inv:")
print(MT_inv)
print("\n验证 MT * MT_inv 是否为单位矩阵:")
print(MT * MT_inv)