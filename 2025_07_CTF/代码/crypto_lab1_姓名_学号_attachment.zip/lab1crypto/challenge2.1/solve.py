# SageMath 环境

# 0. 基础设置
Z256 = Zmod(256)

def is_printable(char_code):
    """检查一个数值是否是可打印ASCII码 (范围 [32, 126])"""
    return 32 <= char_code <= 126

# 1. 已知密文 
result = b'\xfc\xf2\x1dE\xf7\xd8\xf7\x1e\xed\xccQ\x8b9:z\xb5\xc7\xca\xea\xcd\xb4b\xdd\xcb\xf2\x939\x0b\xec\xf2'

# 2. 按列填充，正确构建密文矩阵 RT
RT = matrix(Z256, 3, 10)
for j in range(10):      # 遍历列
    for i in range(3):  # 遍历行
        RT[i, j] = result[i + j * 3]

print("✅ 已成功构建密文矩阵 RT (3x10)")
print("-" * 40)

# 提取方程中需要的密文列向量
c1, c2, c10 = RT.column(0), RT.column(1), RT.column(9)

# 存储所有可能的候选行
d1_candidates, d2_candidates, d3_candidates = [], [], []

# -------------------------------------------------------------------
# Part 3.1: 搜索D的第一行所有可能的候选项
# -------------------------------------------------------------------
print("⏳ 搜索 D 的第一行所有候选项...")
inv69 = Z256(69)^(-1)
for d12_val in range(256):
    for d13_val in range(256):
        # 根据方程 d1*c2 = 123 求解 d11
        d11_sol = (123 - c2[1]*d12_val - c2[2]*d13_val) * inv69
        # 验证是否满足另一个方程 d1*c1 = 65
        if c1[0]*d11_sol + c1[1]*d12_val + c1[2]*d13_val == 65:
            d1_candidate = vector(Z256, [d11_sol, d12_val, d13_val])
            # 验证解密出的整行明文是否都可打印
            if all(is_printable(p) for p in d1_candidate * RT):
                d1_candidates.append(d1_candidate)
print(f"🎉 找到 {len(d1_candidates)} 个第一行候选项: {d1_candidates}")
print("-" * 40)

# -------------------------------------------------------------------
# Part 3.2: 搜索D的第二行所有可能的候选项
# -------------------------------------------------------------------
print("⏳ 搜索 D 的第二行所有候选项...")
inv29 = Z256(29)^(-1)
for d21_val in range(256):
    for d22_val in range(256):
        # 根据方程 d2*c1 = 65 求解 d23
        d23_sol = (65 - c1[0]*d21_val - c1[1]*d22_val) * inv29
        d2_candidate = vector(Z256, [d21_val, d22_val, d23_sol])
        # 验证解密出的整行明文是否都可打印
        if all(is_printable(p) for p in d2_candidate * RT):
            d2_candidates.append(d2_candidate)
print(f"🎉 找到 {len(d2_candidates)} 个第二行候选项: {d2_candidates}")
print("-" * 40)

# -------------------------------------------------------------------
# Part 3.3: 搜索D的第三行所有可能的候选项
# -------------------------------------------------------------------
print("⏳ 搜索 D 的第三行所有候選項...")
inv11 = Z256(11)^(-1)
for d32_val in range(256):
    for d33_val in range(256):
        # 根据方程 d3*c10 = 125 求解 d31
        d31_sol = (125 - c10[1]*d32_val - c10[2]*d33_val) * inv11
        # 验证是否满足另一个方程 d3*c1 = 65
        if c1[0]*d31_sol + c1[1]*d32_val + c1[2]*d33_val == 65:
            d3_candidate = vector(Z256, [d31_sol, d32_val, d33_val])
            # 验证解密出的整行明文是否都可打印
            if all(is_printable(p) for p in d3_candidate * RT):
                d3_candidates.append(d3_candidate)
print(f"🎉 找到 {len(d3_candidates)} 個第三行候選項: {d3_candidates}")
print("-" * 40)

# -------------------------------------------------------------------
# Part 4: 组合所有候选项，找到唯一可逆的解密矩阵 D
# -------------------------------------------------------------------
print("⏳ 组合所有候选项，寻找唯一可逆的解密矩阵...")
D_sol = None
for d1 in d1_candidates:
    for d2 in d2_candidates:
        for d3 in d3_candidates:
            D_candidate = matrix([d1, d2, d3])
            # is_invertible() 在 Zmod(n) 中等价于检查 det() 是否与 n 互质 (即是否为奇数)
            if D_candidate.is_invertible():
                D_sol = D_candidate
                print(f"✅ 找到唯一可逆解密矩阵！Det(D) = {D_sol.det()} (奇数)")
                break
        if D_sol: break
    if D_sol: break

# 5. 输出所有最终结果
if D_sol:
    # 原始加密密钥矩阵 MT
    MT_sol = D_sol.inverse()
    
    # 明文矩阵 P (FT)
    FT_sol = D_sol * RT
    
    # 还原 Flag 字符串
    flag_chars = [''] * 30
    for j in range(10):
        for i in range(3):
            flag_chars[i + j * 3] = chr(int(FT_sol[i, j]))
    final_flag = "".join(flag_chars)
    
    # 格式化输出
    print("\n" + "="*50)
    print("🎊 所有计算已完成，最终结果如下：")
    print("="*50 + "\n")
    
    print("🚩 Flag:")
    print(final_flag)
    print("\n--------------------------------------------------\n")
    
    print("明文矩阵 P (FT):")
    print(FT_sol)
    print("\n--------------------------------------------------\n")
    
    print("解密密钥矩阵 D (MT.inverse()):")
    print(D_sol)
    print("\n--------------------------------------------------\n")
    
    print("原始加密密钥矩阵 MT:")
    print(MT_sol)
else:
    print("\n❌ 错误：未能从候选项中找到任何可逆的解密矩阵。")