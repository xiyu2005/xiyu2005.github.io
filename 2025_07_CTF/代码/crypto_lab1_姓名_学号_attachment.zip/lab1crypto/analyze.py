# -*- coding: utf-8 -*-
import sys

def analyze_word_statistics(filepath='cipher.txt'):
    """
    读取密文文件，分析单词频率和字符位置。
    """
    # 1. 读取文件

    with open(filepath, 'r', encoding='utf-8') as f:
        text_content = f.read()


    # 2. 核心逻辑：严格按照单个空格分割单词
    words = text_content.split(' ')

    # 3. 数据结构优化：使用单一字典存储所有统计信息
    # 结构为: { "单词": {"freq": 频率, "positions": [位置列表]} }
    word_stats = {}
    
    # 初始化字符位置计数器
    char_index = 0

    # 4. 循环逻辑改写：遍历单词并填充新的数据结构
    for word in words:
        # 如果单词是第一次出现，setdefault会为它创建一个新的字典作为值
        entry = word_stats.setdefault(word, {"freq": 0, "positions": []})
        
        # 更新频率和位置信息
        entry["freq"] += 1
        entry["positions"].append(char_index)
        

        char_index += len(word) + 1
    
    # 5. 排序逻辑调整：根据新的数据结构调整排序的 key
    # item[0] 是单词, item[1] 是包含 freq 和 positions 的字典
    sorted_items = sorted(word_stats.items(), key=lambda item: item[1]["freq"], reverse=True)

    # 6. 格式化输出，保持清晰可读
    print("分析完成。")
    print(f"独立词汇数: {len(word_stats)}")
    print("-" * 60)
    print("词频与字符位置分析 (按频率降序显示前 25 名)")
    print("-" * 60)

    for i, (word, stats) in enumerate(sorted_items[:25]):
        frequency = stats["freq"]
        positions = stats["positions"]
        
        pos_preview = str(positions).strip('[]')

            
        print(f"单词: \"{word}\"")
        print(f"  - 频率: {frequency} 次")
        print(f"  - 字符位置 : {pos_preview}")
        print()

if __name__ == '__main__':
    analyze_word_statistics()