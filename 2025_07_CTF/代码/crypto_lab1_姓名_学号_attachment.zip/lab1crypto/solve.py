# -*- coding: utf-8 -*-
import sys

# --- 全局常量 ---

# 加密时使用的字符集
TEXT_LIST = ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\t\n'
# 字符集长度，也是模运算的模数
MOD = len(TEXT_LIST)
# 字符到索引的快速查找映射
TEXT_MAP = {char: i for i, char in enumerate(TEXT_LIST)}
# 已知的密钥长度
KEY_LENGTH = 29

# 标准英文文本中，各字符的近似出现频率（概率）
# 这个列表有 97 个元素，与 TEXT_LIST 的长度完全匹配
ENGLISH_FREQS = [
    0.1828, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0010, 0.0020, 0.0010, 0.0080, 0.0001,
    0.0040, 0.0040, 0.0040, 0.0040, 0.0040, 0.0040, 0.0040, 0.0040, 0.0040, 0.0040, 0.0010, 0.0010, 0.0010, 0.0010, 0.0010, 0.0010, 0.0010,
    0.0651, 0.0125, 0.0221, 0.0321, 0.1031, 0.0208, 0.0152, 0.0468, 0.0599, 0.0010, 0.0055, 0.0324, 0.0205, 0.0602, 0.0799, 0.0150,
    0.0008, 0.0496, 0.0550, 0.0751, 0.0225, 0.0080, 0.0173, 0.0012, 0.0154, 0.0014,
    0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001,
    0.0651, 0.0125, 0.0221, 0.0321, 0.1031, 0.0208, 0.0152, 0.0468, 0.0599, 0.0010, 0.0055, 0.0324, 0.0205, 0.0602, 0.0799, 0.0150,
    0.0008, 0.0496, 0.0550, 0.0751, 0.0225, 0.0080, 0.0173, 0.0012, 0.0154, 0.0014,
    0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001
]


# --- 辅助函数 ---

def calculate_chi_squared(text: str) -> float:
    """计算给定文本的卡方值，以判断其与英文的相似度。值越低，越像英文。"""
    text_len = len(text)
    if text_len == 0:
        return float('inf')
    
    observed_counts = [0] * MOD
    for char in text:
        if char in TEXT_MAP:
            observed_counts[TEXT_MAP[char]] += 1

    chi_squared_val = 0.0
    for i in range(MOD):
        expected_count = text_len * ENGLISH_FREQS[i]
        if expected_count > 0:
            difference = observed_counts[i] - expected_count
            chi_squared_val += difference**2 / expected_count
    return chi_squared_val

def decrypt_full(ciphertext: str, key: list) -> str:
    """使用给定的完整密钥列表解密全文。"""
    plain_text = []
    key_len = len(key)
    for i, char_c in enumerate(ciphertext):
        try:
            key_val = key[i % key_len]
            inv_k = pow(key_val, MOD - 2, MOD)
            c_idx = TEXT_MAP[char_c]
            p_idx = (c_idx * inv_k) % MOD
            plain_text.append(TEXT_LIST[p_idx])
        except (KeyError, ValueError):
            plain_text.append('?')
    return "".join(plain_text)

# --- 主程序 ---

def main():
    """主执行函数，系统性破解密钥并解密。"""
    try:
        with open('cipher.txt', 'r', encoding='utf-8') as f:
            ciphertext = f.read().replace('\u00A0', ' ')
        print("成功从 'cipher.txt' 文件加载密文。")
    except FileNotFoundError:
        print("错误: 'cipher.txt' 文件未在当前目录中找到。")
        sys.exit(1)

    print(f"\n开始破解，已知密钥长度为 {KEY_LENGTH}...")
    found_key = []

    # 1. 遍历密钥的每一个位置
    for i in range(KEY_LENGTH):
        print(f"--- 正在破解密钥的第 {i+1}/{KEY_LENGTH} 位 ---")
        
        # 2. 提取出由该位置密钥加密的所有字符（构成一个分组）
        sub_cipher = ciphertext[i::KEY_LENGTH]
        
        best_k_for_pos = -1
        min_chi_score = float('inf')

        # 3. 遍历所有可能的密钥值 (1 到 96)
        for k_guess in range(1, MOD):
            # 仅用当前的猜测值 k_guess 解密这个分组
            inv_k = pow(k_guess, MOD - 2, MOD)
            decrypted_sub_list = []
            for char_c in sub_cipher:
                if char_c in TEXT_MAP:
                    c_idx = TEXT_MAP[char_c]
                    p_idx = (c_idx * inv_k) % MOD
                    decrypted_sub_list.append(TEXT_LIST[p_idx])
            decrypted_sub = "".join(decrypted_sub_list)

            # 4. 计算卡方值，找到分数最低（最像英文）的那个密钥值
            score = calculate_chi_squared(decrypted_sub)
            if score < min_chi_score:
                min_chi_score = score
                best_k_for_pos = k_guess
        
        print(f"找到第 {i+1} 位密钥: {best_k_for_pos} (卡方值: {min_chi_score:.2f})")
        found_key.append(best_k_for_pos)

    # 5. 组合密钥并解密全文
    print("\n" + "="*50)
    print("密钥破解完成！")
    print(f"破解出的完整密钥为: {found_key}")
    print("="*50 + "\n")

    full_plain_text = decrypt_full(ciphertext, found_key)

    print("--- 完整解密后的明文如下 ---")
    print(full_plain_text)

    # 6. 查找并高亮显示 flag
    flag_start = full_plain_text.find("flag{")
    if flag_start != -1:
        flag_end = full_plain_text.find("}", flag_start)
        if flag_end != -1:
            print("\n" + "="*50)
            print("--- 成功找到 Flag ---")
            print(full_plain_text[flag_start : flag_end + 1])
            print("="*50)

if __name__ == "__main__":
    main()