import base64

# 题目中给出的、经过补齐的Base64字符串
# 注意：原始故事中的 "AQIg GAZ5..." 中间有一个空格，这里已将其移除，这是标准做法。
b64_string = "MIGrAgEAAiEAwmNq5cPY5D/7l6sJAo8arGwL9s09cOvKKBv/6X++MN0CAwEAAQIgGAZ5m9RM5kkSK3i0MGDHhvi3f7FZPghC2gY="

try:
    # 1. 使用 base64.b64decode() 函数将字符串解码为bytes对象
    der_bytes = base64.b64decode(b64_string)

    # 2. 使用 .hex() 方法将bytes对象转换为十六进制字符串
    der_hex = der_bytes.hex()

    # --- 输出结果 ---
    print("--- RSA密钥解码验证 ---")
    print(f"输入的Base64: {b64_string}")
    print(f"\n解码后的DER (十六进制):")
    print(der_hex)

    # 为了方便与上一篇报告中的格式对比，输出一个带空格的版本
    der_hex_spaced = ' '.join(der_hex[i:i+2] for i in range(0, len(der_hex), 2))
    print(f"\n解码后的DER (带空格格式):")
    print(der_hex_spaced)

    # 3. 与报告中的结果进行比对验证
    expected_hex = "3081ab020100022100c2636ae5c3d8e43ffb97ab09028f1aac6c0bf6cd3d70ebca281bffe97fbe30dd020301000102201806799bd44ce649122b78b43060c786f8b77fb1593e0842da06"
    print("\n--- 验证 ---")
    if der_hex == expected_hex:
        print("✅ 验证成功！脚本输出与报告中的十六进制结果完全一致。")
    else:
        print("❌ 验证失败！请检查输入的Base64字符串。")

except Exception as e:
    print(f"解码时发生错误: {e}")
    print("请确保输入的Base64字符串是有效的，并且填充正确。")