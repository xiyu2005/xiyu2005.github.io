import math
import time
import binascii

# --- 题目给定的参数 ---
n_hex = "c2636ae5c3d8e43ffb97ab09028f1aac6c0bf6cd3d70ebca281bffe97fbe30dd"
n = int(n_hex, 16)
e = 65537
c_hex = "1c194cd4f48d77b2e14cace43869bea17615ab23da0ef63b7bf56116ad3ac93b"
c = int(c_hex, 16)

# --- 因数分解算法 ---

def trial_division(num, limit=1000000):
    """
    试除法：尝试用小于limit的数来整除num。
    对于大的RSA模数，基本无效，除非它有一个小素因数。
    """
    print(f"[INFO] 正在尝试试除法 (上限: {limit})...")
    # 尝试 2
    if num % 2 == 0:
        return 2
    # 尝试从3开始的奇数
    for i in range(3, limit + 1, 2):
        if num % i == 0:
            print(f"[SUCCESS] 通过试除法找到一个因子: {i}")
            return i
    print("[INFO] 试除法在指定限制内未找到因子。")
    return None

def pollards_rho(num):
    """
    Pollard's Rho 算法：一种更高效的因数分解算法，但对256位仍然很慢。
    """
    print("[INFO] 正在尝试 Pollard's Rho 算法...")
    start_time = time.time()
    
    # Python 3.9+ 有 math.gcd, 否则需要自己实现
    from math import gcd

    # 定义多项式 g(x) = (x^2 + 1) mod num
    def g(x):
        return (x * x + 1) % num

    x = 2
    y = 2
    d = 1
    
    while d == 1:
        x = g(x)
        y = g(g(y))
        d = gcd(abs(x - y), num)

        # 增加一个超时检查，防止无限运行
        if time.time() - start_time > 300: # 运行5分钟后超时
             print("[FAIL] Pollard's Rho 算法运行超时（5分钟），未找到因子。")
             return None

    if d == num:
        print("[FAIL] Pollard's Rho 算法失败，请尝试其他初始值。")
        return None
    else:
        print(f"[SUCCESS] 通过 Pollard's Rho 找到一个因子: {d}")
        return d

# --- 主逻辑 ---

def factor_and_decrypt(n, e, c):
    print("--- 开始分解RSA模数 n ---")
    print(f"n = {n}")

    p = None
    # 优先尝试简单的试除法
    p = trial_division(n)
    
    # 如果试除法失败，尝试Pollard's Rho
    if not p:
        p = pollards_rho(n)

    if not p:
        print("\n--- 结论 ---")
        print("所有分解尝试均失败。这强烈暗示直接分解 n 不是此题的预期解法。")
        print("请回顾第三部分：'RSA私钥高位攻击'，那才是真正的突破口。")
        return

    # --- 如果分解成功（可能性极低） ---
    print("\n--- 分解成功！开始计算私钥并解密 ---")
    q = n // p
    
    # 确认 p 和 q 是素数（此处省略严格的素性检验）
    print(f"p = {p}")
    print(f"q = {q}")

    # 计算 phi(n)
    phi_n = (p - 1) * (q - 1)
    print(f"phi(n) = {phi_n}")

    # 计算私钥 d (e的模反元素)
    # pow(e, -1, phi_n) 是Python 3.8+的写法
    try:
        d = pow(e, -1, phi_n)
        print(f"计算出的完整私钥 d = {d}")
    except ValueError:
        print("[ERROR] 无法计算私钥d，可能e和phi(n)不互素。")
        return

    # 使用私钥 d 解密
    m = pow(c, d, n)
    print(f"\n解密后的明文 (十进制) = {m}")

    # 将明文转换为可读的字符串
    try:
        flag_hex = hex(m)[2:]
        flag = binascii.unhexlify(flag_hex)
        print(f"解密后的Flag (bytes) = {flag}")
        print(f"尝试用UTF-8解码: {flag.decode('utf-8', errors='ignore')}")
    except Exception as ex:
        print(f"无法将明文转换为字符串: {ex}")

# 运行主程序
if __name__ == "__main__":
    factor_and_decrypt(n, e, c)