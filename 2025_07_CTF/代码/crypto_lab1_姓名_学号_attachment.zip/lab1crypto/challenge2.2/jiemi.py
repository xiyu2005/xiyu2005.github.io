# SageMath 或装有 gmpy2 的 Python 环境均可运行

# --- 已知参数和新发现的因子 ---

# 1. 从 factordb 得到的核心因子 p 和 q
p = 275127860351348928173285174381581152299
q = 319576316814478949870590164193048041239

# 2. 题目中已知的 e 和 n
# 我们可以通过 p*q 重新计算 n 来验证
n = p * q 
e = 65537

# 3. 题目中给出的十六进制密文 c
c_hex = "1c194cd4f48d77b2e14cace43869bea17615ab23da0ef63b7bf56116ad3ac93b"
c = int(c_hex, 16)


# --- 解密过程 ---

# 1. 计算 phi(n)
phi_n = (p - 1) * (q - 1)
print(f"[计算] 成功计算出 phi(n): {phi_n}")

# 2. 计算私钥 d
# pow(e, -1, phi_n) 是计算模反元素的标准方法 (需要 Python 3.8+)
d = pow(e, -1, phi_n)
print(f"[计算] 成功计算出完整私钥 d: {d}")

# 3. 解密密文 c
m = pow(c, d, n)
print(f"\n[解密] 成功解密出明文 (整数形式): {m}")

# 4. 将明文数字转换为可读的字符串
try:
    m_hex = hex(m)[2:]
    # 如果十六进制长度为奇数，前面补0
    if len(m_hex) % 2 != 0:
        m_hex = '0' + m_hex
    
    flag_bytes = bytes.fromhex(m_hex)
    print(f"         明文 (bytes 格式): {flag_bytes}")
    
    # CTF的flag通常是UTF-8编码的字符串
    final_flag = flag_bytes.decode('utf-8', errors='ignore')
    print(f"\n✅ 最终答案 (Flag): {final_flag}")
except Exception as ex:
    print(f"\n[错误] 将明文转换为字符串时出错: {ex}")