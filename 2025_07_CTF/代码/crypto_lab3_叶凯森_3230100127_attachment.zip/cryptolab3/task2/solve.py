from Crypto.Util.number import long_to_bytes, inverse
import gmpy2

# Given values from the problem
N = 82026098918018048601194427731265610598223143352871384484378934781046426470457579869232011486393874476186567625229332611565234003485853019792322430103277676424566512296566435084827135288544968265487309622073434095546441271535068838054181929434974538632566184260907608065199111062758256040088180223324312299521
c1 = 78503948254615594047841187530965836154632787302768366632905121918314810223128105309641358695950697599583708248054782780095462351919922323260220861647550036312494475737008242958470205866004114155607402483934916420785113923454730105142298778088992828889793793717895774511556825375972210918015083059093162818541
c2 = 75091246193148131303260170510260975611473539420282599051834536707253450049850812089631209934399750953992686331190657768055844747861862355060627611276305156746537479184911696938445168043449670586668792029452049248247572227027801974529674890256309603329146410829505466430516915677054283639183184264639627097887

def fermat_factor(n, limit=1000000):
    """
    Tries to factor n using Fermat's factorization method.
    """
    # Start searching from the ceiling of sqrt(n)
    a = gmpy2.isqrt(n) + 1
    
    # We don't expect the difference to be huge, so we set a reasonable search limit.
    for i in range(limit):
        a_i = a + i
        b2 = a_i * a_i - n
        if gmpy2.is_square(b2):
            b = gmpy2.isqrt(b2)
            p = a_i + b
            q = a_i - b
            # Check if it's a non-trivial factorization
            if p * q == n and p != 1 and q != 1:
                return p, q
    return None, None

def solve_crt(a1, n1, a2, n2):
    """
    Solves the system of congruences:
    x = a1 (mod n1)
    x = a2 (mod n2)
    """
    # We need to find m such that:
    # m = c1 (mod p)
    # m = c2 (mod q)
    #
    # According to CRT, the solution is:
    # m = c1 * q_inv * q + c2 * p_inv * p (mod N)
    # where q_inv is the modular inverse of q mod p
    # and p_inv is the modular inverse of p mod q
    
    p = n1
    q = n2
    
    q_inv = inverse(q, p)
    p_inv = inverse(p, q)
    
    # Calculate terms
    term1 = a1 * q_inv * q
    term2 = a2 * p_inv * p
    
    m = (term1 + term2) % (p * q)
    return m

# --- Main execution ---
print("Attempting to factor N using Fermat's method...")
p, q = fermat_factor(N)

if p and q:
    print(f"Successfully factored N!")
    # Ensure p and q are correctly assigned based on the derivation
    # m = c1 (mod p) and m = c2 (mod q)
    print(f"p = {p}")
    print(f"q = {q}")

    print("\nSolving for m using Chinese Remainder Theorem...")
    # We have the system:
    # m = c1 (mod p)
    # m = c2 (mod q)
    
    # Note: The values c1 and c2 are large, we need to take them modulo p and q
    m_p = c1 % p
    m_q = c2 % q
    
    # Ensure our logic is correct.
    # From derivation: c1 = m (mod p), so m_p should be c1 mod p. This is correct.
    # From derivation: c2 = m (mod q), so m_q should be c2 mod q. This is correct.
    
    m = solve_crt(m_p, p, m_q, q)
    
    print(f"\nRecovered m (integer): {m}")

    try:
        flag = long_to_bytes(m)
        print(f"\nRecovered flag: {flag.decode()}")
    except Exception as e:
        print(f"\nCould not decode flag: {e}")
        print(f"Flag in bytes: {flag}")

else:
    print("\nFailed to factor N using Fermat's method within the search limit.")
    print("This suggests that p and q are not close enough for this method to be efficient,")
    print("or another method is required.")