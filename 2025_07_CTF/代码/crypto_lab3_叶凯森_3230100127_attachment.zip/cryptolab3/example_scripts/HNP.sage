from Crypto.Util.number import *
from random import randint

n = 100
p = getPrime(128)
a = [randint(0, p-1) for _ in range(n)]
k = [getPrime(110) for _ in range(n)]
x = randint(0, p-1)
b = [(k[i]-a[i]*x) % p for i in range(n)]

L = [(k[i]-a[i]*x) // p for i in range(n)]
for i in range(n):
    assert L[i]*p+b[i]+a[i]*x ==k[i]

C1 = 2^(128-110)
C2 = 2^128
left = vector(ZZ, L + [x, 1])
target = vector(ZZ, [i * C1 for i in k] + [x, C2])

M = matrix(ZZ, n+2, n+2)

for i in range(n):
    M[i, i] = p * C1
    M[-2, i] = a[i] * C1
    M[-1, i] = b[i] * C1
M[-2, -2] = 1
M[-1, -1] = C2

assert left * M == target

ML = M.LLL()
for i in ML:
    if abs(i[-1]) == C2:
        print(i)
print(target)