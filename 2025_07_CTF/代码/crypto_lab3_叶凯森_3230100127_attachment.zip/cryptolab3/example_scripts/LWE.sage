from Crypto.Util.number import *
from random import randint

n = 40
p = getPrime(64)
A = [[randint(0, p-1) for i in range(n)] for j in range(n)]
x = [randint(0, 1) for _ in range(n)]
e = [randint(0, 20) for _ in range(n)]

b = []
L = []
for i in range(n):
    tmp = 0
    for j in range(n):
        tmp += A[i][j] * x[j]
    tmp += e[i]
    b.append(tmp % p)
    L.append(tmp // p)

for i in range(n):
    assert L[i] * p + b[i] == sum([A[i][j] * x[j] for j in range(n)]) + e[i]

C = 20
left = vector(ZZ, L + x + [1])
target = vector(ZZ, e + [i * C for i in x] + [C])

M = matrix(ZZ, 2*n+1, 2*n+1)

for i in range(n):
    M[i, i] = p
    for j in range(n):
        M[i+n, j] = -A[j][i]
    M[-1, i] = b[i]

for i in range(n):
    M[i+n, i+n] = C

M[-1, -1] = C

assert left * M == target

ML = M.LLL()

print(ML[0])
print(target)