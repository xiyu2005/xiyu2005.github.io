from Crypto.Util.number import *
from random import randint

n = 60
p = getPrime(128)
a = [randint(0, p-1) for _ in range(n)]
s = [randint(0, 1) for _ in range(n)]
S = sum([a[i]*s[i] for i in range(n)]) % p

l = sum([a[i]*s[i] for i in range(n)]) // p
assert l*p + S == sum([a[i]*s[i] for i in range(n)])

left = vector(ZZ, s + [-1, -l])
target = vector(ZZ, s + [-1, 0])

M = matrix(ZZ, n+2, n+2)
for i in range(n):
    M[i, i] = 1
    M[i, -1] = a[i]

M[-2, -2] = 1
M[-2, -1] = S
M[-1, -1] = p

assert left * M == target

ML = M.BKZ(block_size = 20)
print(ML[0])
print(target)