from Crypto.Util.number import *

p = getPrime(2048)
f = getPrime(1024)
g = getPrime(768)
h = g * inverse(f, p) % p
message = bytes_to_long(b"flag{this_is_a_sample_flag}")

r = getPrime(1024)
c = (r * h + message) % p

M = matrix(ZZ, 2, 2)
M[0, 0] = 1
M[0, 1] = h
M[1, 1] = p

ML = M.LLL()[0]
ff, gg = abs(ML[0]), abs(ML[1])
flag = ((c * f) % p) % g * inverse(f, g) % g
print(long_to_bytes(ZZ(flag)))