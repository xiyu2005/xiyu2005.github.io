#!/bin/bash

# 固定参数
COOKIE="TWFID=c3c56f899751ff7b"  # 替换为你的 Cookie 值
LOCAL_PORT="127.0.0.1:61234"
WEBSOCKET_URL="ws://zjusec-com-s.webvpn.zju.edu.cn:8001/api/proxy/6c703186-1e12-4f56-9161-47062c979805"

echo "Connecting to WebSocket proxy..."
websocat -H="Cookie: $COOKIE" -b -E tcp-l:"$LOCAL_PORT" "$WEBSOCKET_URL"

