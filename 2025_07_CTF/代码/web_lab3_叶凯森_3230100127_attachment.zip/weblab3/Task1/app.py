from flask import Flask, request,render_template_string
import sqlite3

app = Flask(__name__)

@app.route('/')
def index():
    name = ""
    id = request.args.get('id')
    conn = sqlite3.connect('info.db')
    c = conn.cursor()
    query = f"SELECT username FROM users WHERE id = {id}"
    try:
        c.execute(query)
        results = c.fetchall()
    except Exception as e:
        return f"Error: {e}"

    if results:
        name = results[0][0]
    
    template = '''
        <html>
          <head>
            <title>SSTI</title>
          </head>
         <body>
              <h3>Hello, %s !</h3>
          </body>
        </html>
        '''% (name)
    return render_template_string(template)


if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=False)