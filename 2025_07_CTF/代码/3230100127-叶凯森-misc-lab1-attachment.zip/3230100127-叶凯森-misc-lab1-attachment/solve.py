# 确认无误的、包含54个字母的加密字符串
encoded_string = "BPLQECUPEZFTSUJJQDZWGGXBOXZMEUZSDHVGKVMNEVWSDKICMAIUOB"

# 初始化一个值为0的大数，用来存放十进制结果
base10_value = 0

# 步骤1：从 Base26 转换为十进制大数
for char in encoded_string:
    char_value = ord(char) - ord('A')  # 将 B 转换为 1, P 转换为 15, etc.
    base10_value = base10_value * 26 + char_value

# 初始化一个空字符串，用于存放最终解码结果
decoded_flag = ""

# 步骤2：从十进制大数转换为 Base256 (ASCII)
while base10_value > 0:
    # 对256取余数，得到一个 0-255 范围的 ASCII 码
    ascii_code = base10_value % 256
    
    # 将 ASCII 码转换为对应的字符，并“从左侧”添加到结果字符串中
    decoded_flag = chr(ascii_code) + decoded_flag
    
    # Python 的整除，为下一次循环做准备
    base10_value //= 256

# 打印最终解码出的 flag
print(decoded_flag)