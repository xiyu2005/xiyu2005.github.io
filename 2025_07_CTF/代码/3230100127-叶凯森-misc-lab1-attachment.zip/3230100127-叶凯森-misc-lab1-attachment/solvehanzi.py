# -*- coding: utf-8 -*-
import itertools
def solve_ctf_from_file(filename="字.txt"):
    """
    此函数从外部文本文件读取数据，通过识别视觉相似但Unicode编码不同的汉字
    来提取隐藏的二进制信息，并将其可视化以获得最终的Flag。
    """
    
    # 1. 定义数据
    # 从指定文件读取含有隐藏信息的原始文本
    try:
        # 使用'with'语句确保文件被正确关闭，并指定UTF-8编码
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
        print(f"成功从文件 '{filename}' 读取内容。")
    except FileNotFoundError:
        print(f"错误: 文件 '{filename}' 未找到。")
        print("请确保你已经创建了该文件，并将其与Python脚本放在同一个目录下。")
        return
    except Exception as e:
        print(f"读取文件时发生错误: {e}")
        return

    # 普通字符（对应比特 '0'）
    normal_chars = "一二人入八几力十又口土士大子小山工手文方无日月木止比毛氏水玄玉生用目石示立竹老而自至色行言赤足身酉里金隶青非面革音骨鬲"
    # 特殊字符，即康熙部首（对应比特 '1'）
    special_chars = "⼀⼆⼈⼊⼋⼏⼒⼗⼜⼝⼟⼠⼤⼦⼩⼭⼯⼿⽂⽅⽆⽇⽉⽊⽌⽐⽑⽒⽔⽞⽟⽣⽤⽬⽯⽰⽴⽵⽼⽽⾃⾄⾊⾏⾔⾚⾜⾝⾣⾥⾦⾪⾭⾮⾯⾰⾳⾻⿀"

    # 2. 建立从字符到比特的映射
    char_to_bit_map = {}
    for char in normal_chars:
        char_to_bit_map[char] = '0'
    for char in special_chars:
        char_to_bit_map[char] = '1'

    # 3. 遍历文本，提取二进制流
    binary_stream = "".join([char_to_bit_map[char] for char in text if char in char_to_bit_map])
            
    print(binary_stream,len(binary_stream))
    
    # 4. 将二进制流转换为字节
    source = binary_stream # 这里直接使用上一步得到的二进制流
    int_chunks = (int(source[i:i+7], 2) for i in range(0, len(source), 7))

    #  使用 takewhile 从生成器中取值，直到值等于 127 (0b1111111) 时停止
    valid_chunks = itertools.takewhile(lambda b: b != 0b1111111, int_chunks)

    # 对筛选出的值进行变换，并构建最终的字节序列
    #    0b10100000 等于 160
    output_bytes = bytes(b + 160 for b in valid_chunks)

    print(output_bytes.decode("gbk"))

# 执行解题函数
if __name__ == "__main__":
    # 函数会默认尝试打开名为 "字.txt" 的文件
    solve_ctf_from_file()