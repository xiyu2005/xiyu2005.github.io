# -*- coding: utf-8 -*-

# 假设这是您已经有的一段乱码
# 它是 "你好，世界" (UTF-8) 被错误地用 GBK 解码后得到的结果
mojibake_text = "鍘熺悊绫讳技璐濇柉浜斿崄鍏﷿殑璐濇柉浜屽崄鍏﷿紪鐮佸叾鍐呭﷿涓哄枬褰╁０甯曞笗鍒╅┈榄佸寳鍏嬪洖闊虫煡鐞嗗潎鍖€甯曞笗鍥為煶绁栭瞾浜虹嫄姝ユ帰鎴堝﷿鎷夊潎鍖€鏈变附鍙舵湵涓藉彾榄佸寳鍏嬪痉灏斿﷿绁栭瞾浜哄▉澹﷿繉楂樺皵澶﷿悆楂樺皵澶﷿悆鍩冨厠鏂﷿皠绾垮枬褰╁０濂ユ柉鍗″焹鍏嬫柉灏勭嚎绁栭瞾浜洪害鍏嬪洖闊冲潎鍖€绁栭瞾浜哄﷿鎷夊痉灏斿﷿閰掑簵鑳滃埄鑰呴珮灏斿か鐞冨叕鏂よ儨鍒╄€呴害鍏嬪崄涓€鏈堝洖闊宠儨鍒╄€呭▉澹﷿繉濉炴媺鍏﷿枻寰峰皵濉斿叕鏂ゅ嵃搴︽煡鐞嗛害鍏嬮樋灏旀硶鍗板害鍧囧寑濂ユ柉鍗″枬褰╁０"

print(f"待处理的乱码: {mojibake_text}\n")

try:
    # 步骤 1: 将乱码字符串用当初错误的解码格式(GBK)编码回去，还原成原始字节
    # "乱码".encode(错误的解码格式) -> 原始字节
    intermediate_bytes = mojibake_text.encode('gbk')
    print(f"步骤1: 用 GBK 编码乱码后，还原出的中间字节: \n{intermediate_bytes}\n")

    # 步骤 2: 用当初正确的编码格式(UTF-8)来解码这些还原后的字节
    # 原始字节.decode(正确的编码格式) -> 原始字符串
    recovered_text = intermediate_bytes.decode('utf-8')
    print(f"步骤2: 用 UTF-8 解码中间字节后，成功恢复的文本: \n{recovered_text}")

except UnicodeEncodeError:
    print(f"错误: 无法使用 GBK 对字符串 '{mojibake_text}' 进行编码。")
    print("这可能意味着这段乱码并非由 'UTF-8 -> GBK' 错误产生，或者在复制粘贴过程中有字符丢失。")
except UnicodeDecodeError:
    print(f"错误: 得到的字节序列无法用 UTF-8 解码。")
    print("这可能意味着原始文本并非 UTF-8 编码，或者乱码的产生过程更复杂。")