import base64

# --- 您需要从逆向代码/可执行文件中查找并填充以下数据 ---
# 1. Base64 编码的字符串 (来自 Main 方法)
B64_STRING = "d3l5d3ldRncbEB4fER4YEBg="

# --- 核心解密逻辑 ---

def solve_xor_part():
    """解决XOR和Base64密码部分"""
    print("--- 开始解密 Part 1 (XOR/Base64部分) ---")
    
    # 1. Base64 解码
    try:
        decoded_bytes = base64.b64decode(B64_STRING)
        print(f"Base64 字符串 '{B64_STRING}' 解码成功，得到 {len(decoded_bytes)} 字节。")
    except Exception as e:
        print(f"Base64 解码失败: {e}")
        return

    # 2. 遍历 key (0-127) 进行爆破
    for key in range(128):
        potential_chars = []
        is_printable_flag = True
        
        # 3. 根据 char[i] = key ^ byte[i] 计算
        for byte in decoded_bytes:
            char_code = key ^ byte
            potential_chars.append(chr(char_code))
            
            # 4. 检查是否为合法的ASCII字符
            # 逆向代码检查 <= 0x7F，这里我们用更严格的可打印字符检查
            if not (32 <= char_code <= 126):
                is_printable_flag = False
                break
        
        if is_printable_flag:
            flag_part_1 = "".join(potential_chars)
            print("\n[+] 解密成功！")
            print(f"找到正确的 KEY: {key}")
            print(f"Flag 的后半部分 (17个字符)是: {flag_part_1}")
            return
            
    print("\n[-] 解密失败，未能找到合适的 KEY。")


if __name__ == '__main__':
    solve_xor_part()