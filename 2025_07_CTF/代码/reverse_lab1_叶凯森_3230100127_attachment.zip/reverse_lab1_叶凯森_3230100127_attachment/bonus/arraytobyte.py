# 读取二进制文件
with open('array.bin', 'rb') as f:
    byte_data = f.read()

# 打印字节数据的前几个字节（验证）
print(byte_data[:10])  # 输出类似 b'\x00\x01\x00\x00...'
