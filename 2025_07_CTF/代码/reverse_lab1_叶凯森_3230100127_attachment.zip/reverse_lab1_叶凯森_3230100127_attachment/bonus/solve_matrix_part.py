# 脚本1（已修正版）：使用高斯消元法解密矩阵部分
import numpy as np

# --- 您需要将从dnSpy提取的195字节数据填入这里！ ---
# 读取二进制文件
with open('array.bin', 'rb') as f:
    byte_data = f.read()
SERIALIZED_BYTE_ARRAY = byte_data    # <--- 在此填充您的195字节数据

# --- 核心解密逻辑 ---
MOD = 127

def mod_inverse(n, modulus):
    """计算模逆元"""
    return pow(int(n), -1, modulus) # 在 n 前面加上 int()

def generate_key_matrix(byte_array):
    """根据 GetSquare 的逻辑生成 14x14 的密钥矩阵 M"""
    if not byte_array or len(byte_array) != 195:
        raise ValueError("SERIALIZED_BYTE_ARRAY 数据不正确！应为195字节。")
    dim = 14
    matrix = np.zeros((dim, dim), dtype=int)
    for i in range(dim):
        for j in range(dim):
            index = (7 * (i + j * dim)) % 195
            value = byte_array[index] % MOD
            matrix[i, j] = value
    return matrix

def solve_linear_system_mod(A, b, modulus):
    """
    使用高斯消元法解线性方程组 Ax = b (mod modulus)
    """
    A = np.array(A, dtype=int)
    b = np.array(b, dtype=int)
    n = len(b)
    
    # 构建增广矩阵
    Ab = np.hstack([A, b.reshape(n, 1)])
    
    # --- 前向消元 ---
    for i in range(n):
        # 寻找主元 (pivot)
        pivot_row = i
        while pivot_row < n and Ab[pivot_row, i] == 0:
            pivot_row += 1
        
        if pivot_row == n:
            # 没有唯一解
            raise ValueError("系统没有唯一解，可能矩阵是奇异的。")
            
        # 交换行
        Ab[[i, pivot_row]] = Ab[[pivot_row, i]]

        # 将主元变为1
        inv = mod_inverse(Ab[i, i], modulus)
        Ab[i] = (Ab[i] * inv) % modulus
        
        # 消去下方元素
        for j in range(i + 1, n):
            factor = Ab[j, i]
            Ab[j] = (Ab[j] - Ab[i] * factor) % modulus

    # --- 反向代入 ---
    x = np.zeros(n, dtype=int)
    for i in range(n - 1, -1, -1):
        x[i] = Ab[i, n]
        for j in range(i + 1, n):
            x[i] = (x[i] - Ab[i, j] * x[j]) % modulus
            
    return x

def solve_matrix_part():
    print("--- 开始解密 Part 2 (矩阵部分) ---")
    print("使用高斯消元法进行修正...")
    
    M = generate_key_matrix(SERIALIZED_BYTE_ARRAY)
    v_result_list = [45, 77, 7, 109, 112, 98, 11, 14, 70, 77, 16, 26, 1, 106]
    
    try:
        solution = solve_linear_system_mod(M, v_result_list, MOD)
        flag_part = "".join([chr(c) for c in solution])
        
        print("\n[+] 解密成功！")
        print(f"Flag 的前半部分内容 (14个字符) 是: {flag_part}")
        return flag_part
    except ValueError as e:
        print(f"\n[-] 解密失败: {e}")
        return None

# 运行解密
if __name__ == '__main__':
    matrix_chars = solve_matrix_part()