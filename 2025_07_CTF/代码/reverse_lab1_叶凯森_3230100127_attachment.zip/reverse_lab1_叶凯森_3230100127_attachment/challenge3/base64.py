import base64

def custom_base64_decode(encoded_string, custom_alphabet):
    # 构建从自定义字符到标准Base64字符的转换表
    # 标准Base64字符表
    standard_alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    
    # 确保自定义字符表长度正确
    if len(custom_alphabet) != 64:
        raise ValueError("Custom alphabet must contain 64 characters.")
        
    # 创建转换映射
    translation_map = str.maketrans(custom_alphabet, standard_alphabet)
    
    # 将自定义编码的字符串转换为标准Base64编码的字符串
    standard_b64_string = encoded_string.translate(translation_map)
    
    # 使用标准库进行解码
    # 需要添加正确的padding，否则会报错
    # Base64字符串的长度必须是4的倍数
    padding_needed = len(standard_b64_string) % 4
    if padding_needed:
        standard_b64_string += '=' * (4 - padding_needed)
        
    try:
        decoded_bytes = base64.b64decode(standard_b64_string)
        return decoded_bytes.decode('utf-8') # 假设flag是UTF-8字符串
    except Exception as e:
        return f"An error occurred: {e}"


# 1. 从IDA中提取的64个字符的自定义密码表
custom_alphabet = "qvEJAfHmUYjBac+u8Ph5n9Od17FrICL/X0gVtM4Qk6T2z3wNSsyoebilxWKGZpRD" 

# 2. 从main函数中确认的目标密文
encoded_flag = "5Mc58bPHLiAx7J8ocJIlaVUxaJvMcoYMaoPMaOfg15c475tscHfM/8=="

# 3. 调用自定义Base64解码函数
if len(custom_alphabet) == 64:
    flag = custom_base64_decode(encoded_flag, custom_alphabet)
    print(f"Encoded string: {encoded_flag}")
    print(f"Decoded flag: {flag}")
else:
    print("Error: Please paste the full 64-character custom alphabet from IDA.")