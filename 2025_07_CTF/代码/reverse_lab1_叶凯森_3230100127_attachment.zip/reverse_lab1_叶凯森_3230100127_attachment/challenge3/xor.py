encrypted_string = "MMMwjau`S]]S}ybS?4:;5:<4<q"
key = 0xC

original_flag = "".join([chr(ord(char) ^ key) for char in encrypted_string])

print(f"\n 解密结果: {original_flag}")