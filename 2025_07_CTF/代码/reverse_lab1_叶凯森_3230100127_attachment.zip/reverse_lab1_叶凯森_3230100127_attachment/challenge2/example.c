// example.c
#include <stdio.h>
#include <string.h>

// 一个易受攻击的函数
void unsafe_greet(const char* name) {
    char buffer[64];
    strcpy(buffer, "Hello, "); // 使用危险的strcpy
    strcat(buffer, name);
    printf("Welcome: %s\n", buffer);
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <name>\n", argv[0]);
        return 1;
    }
    unsafe_greet(argv[1]);
    return 0;
}