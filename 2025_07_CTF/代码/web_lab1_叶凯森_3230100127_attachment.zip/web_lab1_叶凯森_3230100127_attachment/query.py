import requests
import pandas as pd
import time

# --- 1. 配置区：请在此处修改个人信息 ---

# 获取COOKIE_STRING：登录教务网 -> F12打开开发者工具 -> Network -> POST请求 -> Headers里找到Cookie并复制其完整值
COOKIE_STRING = "JSESSIONPREJSDM=h%40Q%2CUB0Z%3AO%5EdJj%22%7BHZ7_1R0B0DF3Z%3AO%5E; JSESSIONID=14C9CE1F7B78BF494223E4E1420447DE; _ga=GA1.1.1285005888.1748879575; _ga_H5QC8W782Q=GS2.1.s1750730698$o8$g0$t1750730702$j56$l0$h0; Hm_lvt_35da6f287722b1ee93d185de460f8ba2=1749392187,1751457007; HMACCOUNT=87A914C93093904A; Hm_lpvt_35da6f287722b1ee93d185de460f8ba2=1751457048; JSESSIONID=C4F5F9410AF4A437EE6E2DC946751025; route=1a53339a9972202950f42a60e12340ac; _csrf=S8mwplVi9KWoF2WQ0TlCeCdycKP9AhMZXdhoXhgYRPc%3D; _pv0=KVvdmB1bxwm3NJQy5hTGZJAiDNC82UtzUG2xkWfMjvH%2B7wJ%2F5j7CARhNKQslC5q%2F8kGbWgYyvWFix9TbUXQrWvDG8pw143TwUdGX%2BCxWG%2B4FcSzC3cxbhzaLrvJ5Bw6GFM%2B1k7v4rkqWkn0Gtr2J7ji5nS8NLNOH%2BejYyfGHtKQMQISBLenJujYun7IAlutmF6lCN9gtaY%2FnI3XF4RbKCBWy3RBc%2F6rzaXdKp%2BKo88CrI5sTc1vlXqXrEqIW8GL8GYB7viAL9Vptal0MwdrT407RtYQIjVx%2BGqq0gguC5hm2WXM85lRo99%2F7nmb2HsOQ%2BT7iGsFwCtSWM%2BOFb8lkzbq2HSLTahTFpV8QfnwNuwocLmJ3xHFN8N0SdQXeheSKvU64yj%2Fovg8UnJGxAMj9oN3aDbUFgtxXkgnFb%2BOaaNY%3D; _pf0=tBfLMfHoml0k2W%2FHTvzPJzy51mvzNH06260Wma98OZU%3D; _pc0=tGRO4QiDKs2INomMnZ%2F15rTWSsc3Af5vIZVXFeQfO2HrbrZJoseiXKHNWkA%2FOuS2; iPlanetDirectoryPro=NNIfOajZNIfmikmqvr5DfntxVy8IJSuX32fCMxHys7NI36ru%2FaaJ9Iz7FQuVUvmTX05UXaQzcJXsA%2F4MXlLsLmLR1Ac3EGlMPBhVlh8lkHetAj5B1mgQXGX5r8ta5ixqhdRS9jHO9dtD8wMyyohLXmxkYY1RV5o0x6kVL3lIg3dEXRNWtkdafCSxdSR%2FFpFvKHBmapssKHsnvm9xOb7PeKD5ZjT8%2BJiqIHVQbJx1SxSTT%2Bn9Z7nI5mWCqbJIWoNj2IG%2FIPh%2BNPg3Fk5aOicmWnmzBvM7vnBd11imI5uAIhi74%2FpJFs8rFd4wRQrLh%2Fems6%2Bn%2F2ErO1XjwDz4tqnw96SfJKBD2wCL1w56EJFLJ5A%3D"


# --- 2. 请求参数区：根据上次的分析结果设置 ---

# API的URL地址
API_URL = "https://zdbk.zju.edu.cn/jwglxt/cxdy/xscjcx_cxXscjIndex.html"

# 请求头，模拟浏览器行为
HEADERS = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
    'Cookie': COOKIE_STRING, # 使用上面配置的Cookie
    'Origin': 'https://zdbk.zju.edu.cn',
    'Referer': 'https://zdbk.zju.edu.cn/jwglxt/cxdy/xscjcx_cxXscjIndex.html?gnmkdm=N5083&layout=default&su=3230100127',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/5.37.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
}

# URL的查询参数
URL_PARAMS = {
    'doType': 'query',
    'gnmkdm': 'N5083',
    'su': '3230100127'
}

# POST请求体中的表单数据
#  xnm 和 xqm 设置为要查询的学年和学期
# rows 设置一个较大的值（如100），以确保一次性获取所有成绩，避免分页
FORM_DATA = {
    '_search': 'false',
    'nd': int(time.time() * 1000), # 模仿浏览器生成的时间戳
    'queryModel.showCount': '100', # 每页显示数量
    'queryModel.currentPage': '1',
    'queryModel.sortName': 'xkkh',
    'queryModel.sortOrder': 'asc',
    'time': '0'
}


# --- 3. 执行抓取与数据处理 ---

def fetch_grades():
    """发送请求并获取成绩数据"""
    print("🚀 正在向服务器发送请求，请稍候...")
    try:
        response = requests.post(
            API_URL,
            params=URL_PARAMS,
            headers=HEADERS,
            data=FORM_DATA,
            timeout=10  # 设置10秒超时
        )
        # 检查HTTP响应状态码，如果不是200，则会抛出异常
        response.raise_for_status()

        print("✅ 请求成功，正在解析返回的数据...")
        json_data = response.json()

        # 检查返回的数据是否有效
        if "items" in json_data and json_data["items"]:
            return json_data["items"]
        else:
            # 可能是Cookie失效或没有该学期的成绩
            print("❌ 未找到成绩信息。请检查：")
            print("   1. Cookie是否已过期，需要重新获取。")
            print("   2. 学年(xnm)和学期(xqm)代码是否正确。")
            print("   3. 该学期是否有已公布的成绩。")
            print("\n服务器原始返回内容:")
            print(response.text)
            return None

    except requests.exceptions.RequestException as e:
        print(f"❌ 请求失败，发生网络错误: {e}")
        return None

def display_grades(grades_data):
    """使用pandas格式化并显示成绩"""
    if not grades_data:
        print("\n无法显示成绩，因为没有获取到有效数据。")
        return

    # 将JSON列表转换为pandas DataFrame
    df = pd.DataFrame(grades_data)

    # 选择我们关心的列，并重命名为中文，方便查看
    df_display = df[['kcmc', 'cj', 'jd', 'xf']]
    df_display.columns = ['课程名称', '成绩', '绩点', '学分']

    print("\n---------- 您的本学期成绩单 ----------")
    print(df_display.to_string(index=False))
    print("------------------------------------")
    
    # 计算并打印GPA
    try:
        # 确保成绩和学分列是数字类型
        df['cj_val'] = pd.to_numeric(df['cj'], errors='coerce') # 将'良好'等转为NaN
        df['xf_val'] = pd.to_numeric(df['xf'])
        
        # 过滤掉没有数字成绩或学分的课程（例如PF制的课程）
        df_calc = df.dropna(subset=['cj_val', 'xf_val'])
        
        if not df_calc.empty:
            total_credit_points = (pd.to_numeric(df_calc['jd']) * df_calc['xf_val']).sum()
            total_credits = df_calc['xf_val'].sum()
            gpa = total_credit_points / total_credits if total_credits > 0 else 0
            print(f"\n📊 平均学分绩点 (GPA): {gpa:.3f}")
    except Exception as e:
        print(f"\n⚠️ GPA计算出错: {e}")


if __name__ == "__main__":
      grades = fetch_grades()
      if grades:
          display_grades(grades)