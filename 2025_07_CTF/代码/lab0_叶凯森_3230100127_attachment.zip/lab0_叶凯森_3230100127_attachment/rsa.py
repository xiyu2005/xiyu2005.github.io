from Crypto.Util.number import long_to_bytes

# 给定的参数
p_hex = "0x848cc7edca3d2feef44961881e358cbe924df5bc0f1e7178089ad6dc23fa1eec7b0f1a8c6932b870dd53faf35b22f35c8a7a0d130f69e53a91d0330c0af2c5ab"
q_hex = "0xa0ac7bcd3b1e826fdbd1ee907e592c163dea4a1a94eb03fd4d3ce58c2362100ec20d96ad858f1a21e8c38e1978d27cd3ab833ee344d8618065c003d8ffd0b1cb"
e_hex = "0x10001"
c_hex = "0x39f68bd43d1433e4fcbbe8fc0063661c97639324d63e67dedb6f4ed4501268571f128858b2f97ee7ce0407f24320a922787adf4d0233514934bbd7e81e4b4d07b423949c85ae3cc172ea5bcded917b5f67f18c2c6cd1b2dd98d7db941697ececdfc90507893579081f7e3d5ddeb9145a715abc20c4a938d32131013966bea539"

# 将十六进制字符串转换为整数
p = int(p_hex, 16)
q = int(q_hex, 16)
e = int(e_hex, 16)
c = int(c_hex, 16)

# 1. 计算 n
n = p * q
print(f"n = {n}")

# 2. 计算 phi_n
phi_n = (p - 1) * (q - 1)
print(f"phi_n = {phi_n}")

# 3. 计算 d (私钥指数)
# d * e = 1 (mod phi_n)
# d = pow(e, -1, phi_n)  
d = pow(e, -1, phi_n)
print(f"d = {d}")

# 4. 解密 m
# m = c^d mod n
m_decrypted = pow(c, d, n)
print(f"解密后的 m (整数) = {m_decrypted}")

# 5. 将 m 转换为字节串
m_bytes = long_to_bytes(m_decrypted)
print(f"解密后的 m (字节串) = {m_bytes}")

# 尝试将字节串解码为字符串
try:
    m_string = m_bytes.decode('utf-8')
    print(f"解密后的消息 (字符串) = {m_string}")
except UnicodeDecodeError:
    print(f"解密后的消息 (字符串) 无法以 UTF-8 解码。原始字节串: {m_bytes}")