import xml.etree.ElementTree as ET
import base64
import urllib.parse
import re

# --- 配置开始 ---
# 在之前的交流中，我们确认WAF拦截时的特征信息
WAF_BLOCK_MARKER = "SQL Injection Checked." # 如果实际的WAF拦截信息不同，请修改这里

# 已知的应用响应特征
# （来自你提供的信息：输入1显示的内容为Hello, glzjin wants a girlfriend.输入2显示的内容为Do you want to be my girlfriend?）
TRUE_MARKER_1 = "Hello, glzjin wants a girlfriend."
TRUE_MARKER_2 = "Do you want to be my girlfriend?"
# （来自之前的交流）
FALSE_MARKER = "Error Occured When Fetch Result."
BOOL_FALSE_MARKER = "bool(false)"

# 要提取的参数名
TARGET_PARAM_NAME = "id"
# --- 配置结束 ---

def extract_payload_from_request_body(decoded_request_bytes, param_name):
    """
    从解码后的HTTP请求体中提取指定参数的值。
    请求体通常是 application/x-www-form-urlencoded 格式。
    """
    try:
        # 将字节串按行分割，找到空行（\r\n\r\n 或 \n\n）后的请求体
        parts = decoded_request_bytes.split(b'\r\n\r\n', 1)
        if len(parts) < 2 and b'\n\n' in decoded_request_bytes: # 尝试 \n\n
            parts = decoded_request_bytes.split(b'\n\n', 1)

        if len(parts) == 2:
            body_bytes = parts[1]
            # 解码请求体 (通常是UTF-8)
            body_str = body_bytes.decode('utf-8', errors='ignore')
            parsed_body = urllib.parse.parse_qs(body_str)
            if param_name in parsed_body and parsed_body[param_name]:
                return parsed_body[param_name][0] # 返回第一个值
    except Exception as e:
        # print(f"    [Debug] 解析请求体失败: {e}")
        pass
    return None

def analyze_burp_xml(xml_file_path):
    useful_payloads_info = {} # 存储 {payload: "响应类型描述"}

    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()
    except ET.ParseError as e:
        print(f"[-] XML解析错误: {e}")
        print("[-] 请确保XML文件路径正确且文件内容有效。")
        return useful_payloads_info
    except FileNotFoundError:
        print(f"[-] 文件未找到: {xml_file_path}")
        return useful_payloads_info


    print(f"[+] 正在处理文件: {xml_file_path}")
    item_count = 0
    processed_count = 0

    for item in root.findall('item'):
        item_count += 1
        try:
            # 1. 获取并解码请求
            request_tag = item.find('request')
            encoded_request_content = request_tag.text if request_tag is not None else None
            is_req_base64 = request_tag is not None and request_tag.get('base64') == 'true'
            
            payload_value = None
            if encoded_request_content:
                decoded_request_bytes = b''
                try:
                    if is_req_base64:
                        decoded_request_bytes = base64.b64decode(encoded_request_content)
                    else:
                        decoded_request_bytes = encoded_request_content.encode('utf-8')
                except Exception as e:
                    # print(f"    [Warning] 请求内容base64解码失败 (跳过此项): {e}")
                    continue
                
                payload_value = extract_payload_from_request_body(decoded_request_bytes, TARGET_PARAM_NAME)

            if not payload_value:
                # print(f"    [Info] 未能在请求中找到参数 '{TARGET_PARAM_NAME}' 的值 (跳过此项).")
                continue

            # 2. 获取并解码响应
            response_tag = item.find('response')
            encoded_response_content = response_tag.text if response_tag is not None else None
            is_resp_base64 = response_tag is not None and response_tag.get('base64') == 'true'
            
            decoded_response_body_text = ""
            if encoded_response_content:
                full_decoded_response_bytes = b''
                try:
                    if is_resp_base64:
                        full_decoded_response_bytes = base64.b64decode(encoded_response_content)
                    else:
                        # 如果响应不是base64编码，并且它是完整的HTTP响应，我们依然需要提取body
                        # 但通常Burp导出的非base64响应可能直接就是body，或者就是纯文本
                        # 为简化，这里假设非base64编码的response标签内容是我们可以直接检查的文本
                        # 如果它也是完整HTTP响应，则需要类似请求体的分割逻辑
                        decoded_response_body_text = encoded_response_content
                except Exception as e:
                    # print(f"    [Warning] 响应内容base64解码失败 (跳过此项): {e}")
                    continue

                if is_resp_base64 and full_decoded_response_bytes: # 仅当是base64且解码成功时才分割
                    try:
                        # 分割响应头和响应体
                        resp_parts = full_decoded_response_bytes.split(b'\r\n\r\n', 1)
                        if len(resp_parts) < 2 and b'\n\n' in full_decoded_response_bytes: # 尝试 \n\n
                             resp_parts = full_decoded_response_bytes.split(b'\n\n', 1)

                        if len(resp_parts) == 2:
                            decoded_response_body_text = resp_parts[1].decode('utf-8', errors='ignore')
                        else: # 无法分割，可能只有响应头或格式特殊
                            decoded_response_body_text = full_decoded_response_bytes.decode('utf-8', errors='ignore')
                    except Exception as e:
                        # print(f"    [Warning] 解析响应体失败: {e}")
                        decoded_response_body_text = full_decoded_response_bytes.decode('utf-8', errors='ignore') # 尽力而为


            # 3. 分析响应内容
            if WAF_BLOCK_MARKER in decoded_response_body_text:
                # print(f"    [Filtered] Payload: '{payload_value}' -> WAF拦截")
                continue # 被WAF拦截，不是我们想要的

            response_description = None
            if TRUE_MARKER_1 in decoded_response_body_text:
                response_description = f"成功状态1 (glzjin: {TRUE_MARKER_1[:20]}...)"
            elif TRUE_MARKER_2 in decoded_response_body_text:
                response_description = f"成功状态2 (girlfriend: {TRUE_MARKER_2[:20]}...)"
            elif FALSE_MARKER in decoded_response_body_text:
                response_description = f"失败状态 ({FALSE_MARKER[:20]}...)"
            elif BOOL_FALSE_MARKER in decoded_response_body_text:
                response_description = f"特殊状态 ({BOOL_FALSE_MARKER})"
            
            if response_description:
                if payload_value not in useful_payloads_info:
                    useful_payloads_info[payload_value] = []
                if response_description not in useful_payloads_info[payload_value]: # 避免重复添加完全相同的描述
                    useful_payloads_info[payload_value].append(response_description)
            
            processed_count +=1

        except Exception as e:
            # import traceback
            # print(f"[-] 处理第 {item_count} 个 <item> 时发生意外错误: {e}")
            # traceback.print_exc() # 打印详细的错误堆栈信息
            continue
    
    print(f"[+] 总共处理了 {item_count} 个 <item> 标签。")
    print(f"[+] 其中 {processed_count} 个请求通过了WAF并提取了payload。")
    return useful_payloads_info

if __name__ == "__main__":
    xml_file = input("请输入Burp Suite导出的XML文件名 (例如 burp_export.xml): ")
    
    results = analyze_burp_xml(xml_file)
    
    if results:
        print("\n[+] 识别出的“有用”的Payload (未被WAF拦截且产生了已知应用状态):")
        unique_useful_payloads = set()
        for payload, descriptions in results.items():
            print(f"  Payload: \"{payload}\"")
            for desc in descriptions:
                print(f"    -> {desc}")
            unique_useful_payloads.add(payload)
        
        print(f"\n[+] 共找到 {len(unique_useful_payloads)} 个独特的“有用”payload。")
        print("\n[+] 这些payload可以作为后续构造布尔盲注SQL语句的参考，分析它们哪些字符或结构没有被过滤。")
        # 如果你想将这些payload保存到文件：
        # with open("useful_payloads.txt", "w", encoding="utf-8") as f:
        #     for p in sorted(list(unique_useful_payloads)): #排序后写入
        #         f.write(p + "\n")
        # print("[+] 独特的“有用”payload已保存到 useful_payloads.txt")

    else:
        print("[-] 未找到有用的payload，或处理过程中出现错误。")