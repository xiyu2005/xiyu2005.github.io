import socket
import re # 虽然这里用不到复杂的正则，但备着有时有用

# --- 配置 ---
HOST = '10.214.160.13'  # 目标 IP 地址
PORT = 11002           # 目标端口
TIMEOUT_SOCKET = 8     # 客户端套接字操作超时时间（秒），应小于服务器的10秒超时
NUM_CALCULATIONS = 10  # 总共需要计算的次数

def solve_challenge():
    """
    连接到服务器并解决算术挑战。
    """
    # 使用 with 语句确保套接字在使用完毕后能正确关闭
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            print(f"[*] 正在连接到 {HOST}:{PORT}...")
            s.connect((HOST, PORT))
            s.settimeout(TIMEOUT_SOCKET) # 为套接字操作设置超时
            print("[+] 连接成功！")

            # 用于累积从服务器接收的数据的缓冲区
            data_buffer = b""
            
            # 首先，接收并打印初始的欢迎信息/横幅，直到第一个问题出现
            # 第一个问题通常以 " = " 结尾
            print("\n[*] 正在接收服务器的初始信息...")
            while b" = " not in data_buffer:
                chunk = s.recv(4096)
                if not chunk:
                    print("[-] 服务器在发送第一个问题前关闭了连接。")
                    return
                data_buffer += chunk
            
            # 将接收到的字节数据解码为字符串
            # errors='ignore' 可以避免因特殊字符解码失败导致程序中断
            full_initial_message = data_buffer.decode(errors='ignore')
            
            # 分割消息，" = "之前的是包含横幅和第一个表达式的部分，之后的是缓冲区的剩余部分
            parts = full_initial_message.split(" = ", 1)
            if len(parts) < 2:
                print("[-] 未能从初始信息中解析出第一个问题。")
                print(f"收到的数据: {full_initial_message}")
                return

            # `parts[0]` 包含横幅和第一个表达式的字符串
            # `parts[1]` 包含第一个 " = " 之后的所有数据，需要转回bytes并存起来
            text_before_first_equals = parts[0]
            data_buffer = parts[1].encode(errors='ignore') # 更新缓冲区为第一个 " = " 之后的部分

            # 打印横幅 (即第一个表达式之前的所有行)
            # 表达式通常是 `text_before_first_equals` 的最后一行
            banner_lines, _, first_expression_str = text_before_first_equals.rpartition('\n')
            if banner_lines: # 如果表达式前有其他内容（横幅）
                print(f"{banner_lines.strip()}")
            
            # 如果 rpartition 没找到换行符，说明 text_before_first_equals 就是表达式本身
            if not first_expression_str and not banner_lines and text_before_first_equals:
                 first_expression_str = text_before_first_equals
            
            current_expression_str = first_expression_str.strip()

            # --- 开始循环计算 ---
            for i in range(NUM_CALCULATIONS):
                print(f"\n--- 第 {i + 1} 次计算 ---")

                if i > 0: # 对于第2到第10个问题，需要从缓冲区或网络读取
                    # 确保 data_buffer 包含当前问题的 " = "
                    while b" = " not in data_buffer:
                        chunk = s.recv(4096)
                        if not chunk:
                            print(f"[-] 服务器在接收第 {i + 1} 个问题时关闭了连接。")
                            return
                        data_buffer += chunk
                    
                    # 解码并分割
                    problem_data_str = data_buffer.decode(errors='ignore')
                    parts = problem_data_str.split(" = ", 1)
                    if len(parts) < 2:
                        print(f"[-] 未能解析出第 {i + 1} 个问题。")
                        print(f"当前数据: {problem_data_str}")
                        return
                    
                    # `parts[0]` 可能包含类似 "Correct!\n" 的服务器回应以及新的表达式
                    # 我们取最后一行作为表达式
                    expression_section = parts[0]
                    lines = expression_section.splitlines()
                    if not lines:
                        print(f"[-] 服务器发送了空的表达式部分：'{expression_section}'")
                        return
                    current_expression_str = lines[-1].strip() # 假设表达式在 " = " 之前的最后一行
                    
                    data_buffer = parts[1].encode(errors='ignore') # 更新缓冲区

                if not current_expression_str:
                    print("[-] 当前表达式为空，无法计算。")
                    # 尝试从缓冲区再读一次，看是不是问题没接收完整
                    extra_chunk = s.recv(1024) 
                    data_buffer += extra_chunk
                    print(f"追加读取后缓冲区: {data_buffer.decode(errors='ignore')}")
                    # 这里可以加一个重试逻辑，但简单起见，如果还是空就退出
                    if not current_expression_str and b" = " not in data_buffer: # 还是没找到问题
                         print("[-] 表达式依旧为空，放弃。")
                         return
                    # 如果追加读取后找到了，重新解析 (这部分简化了，实际中可能需要更复杂的缓冲管理)
                    # 为避免复杂化，当前脚本假设每次都能正确分割。

                print(f"题目: {current_expression_str} = ?")

                # 计算结果
                try:
                    # 使用 eval() 计算表达式的值。
                    # 注意：eval() 对于不可信的输入可能存在安全风险。
                    # 但在此类CTF挑战中，对于简单的数学表达式，这是常见且快速的方法。
                    # 添加一个非常基础的检查，确保字符串大致安全
                    safe_chars = set("0123456789+- ")
                    if not all(char in safe_chars for char in current_expression_str if char.strip()):
                        raise ValueError("表达式中包含不允许的字符")
                    
                    result = eval(current_expression_str)
                except Exception as e:
                    print(f"[-] 计算表达式 '{current_expression_str}' 时出错: {e}")
                    return

                # 发送答案
                answer = str(result) + "\n" # 结果需要转换为字符串，并添加换行符
                print(f"计算结果: {result}")
                s.sendall(answer.encode())
                print(f"[*] 已发送答案: {result}")

            # --- 10次计算完成，接收flag ---
            print("\n[+] 所有计算已完成。正在等待Flag...")
            
            # data_buffer 中可能已经包含了部分或全部flag信息
            # 继续接收，直到超时或连接关闭
            try:
                while True:
                    chunk = s.recv(4096)
                    if not chunk: # 服务器关闭连接
                        break
                    data_buffer += chunk
            except socket.timeout:
                print("[*] 读取Flag时发生超时，可能已收到完整Flag。")
            
            flag_message = data_buffer.decode(errors='ignore').strip()
            print("\n================ FLAG ================")
            if flag_message:
                print(flag_message)
            else:
                print("[-] 未能接收到Flag信息。")
            print("====================================")

        except socket.timeout:
            print("[-] 操作超时！服务器可能没有在预期时间内响应。")
            print(f"当前接收缓冲区内容: {data_buffer.decode(errors='ignore') if 'data_buffer' in locals() else 'N/A'}")
        except ConnectionRefusedError:
            print(f"[-] 连接被拒绝。请检查服务器 {HOST}:{PORT} 是否可达并且服务正在运行。")
        except Exception as e:
            print(f"[!] 发生了意外错误: {e}")
            import traceback
            traceback.print_exc() # 打印详细的错误堆栈信息
        finally:
            print("\n[*] 关闭连接。")

if __name__ == '__main__':
    solve_challenge()