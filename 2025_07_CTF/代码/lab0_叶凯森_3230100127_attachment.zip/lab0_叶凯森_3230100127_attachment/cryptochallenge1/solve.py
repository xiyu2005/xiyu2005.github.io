import collections
import os # 主要用于测试时的文件检查，实际分析可以不用

# --- 辅助函数 ---
def get_substituted_string(original_item, substitution_table):
    """
    根据替换表转换字符串（或单个字符）。
    未在表中的字符将保持原样。
    substitution_table 的值（明文）可以是单个字符或字符串。
    """
    if not substitution_table:
        return original_item
    
    # 如果 original_item 是单个字符，直接查找
    if len(original_item) == 1:
        return substitution_table.get(original_item, original_item)

    # 如果 original_item 是字符串 (如 n-gram)，则逐字符替换
    res = []
    for char_ci in original_item:
        plain_char = substitution_table.get(char_ci, char_ci)
        res.append(plain_char)
    return "".join(res)

def format_item_with_substitution(original_item, letter_substitution_table):
    """
    格式化输出，如：原始项(替换后项) 或 原始项 (如果无替换)
    这个函数现在用于第二阶段的字母替换。
    """
    if not letter_substitution_table:
        return original_item

    # 对 original_item (可能包含第一阶段替换后的字符，如 'A', '.') 进行第二阶段替换
    substituted_display_parts = []
    made_any_substitution = False
    for char_in_item in original_item: # original_item 可能是 'A' 或 '.' 或一个n-gram "A.t"
        plain_char = letter_substitution_table.get(char_in_item, char_in_item)
        substituted_display_parts.append(plain_char)
        if char_in_item in letter_substitution_table:
            made_any_substitution = True
            
    if made_any_substitution:
        substituted_part_str = "".join(substituted_display_parts)
        if original_item != substituted_part_str: # 避免 A(A) 或 .(.) 的情况
             return f"{original_item}({substituted_part_str})"
    
    return original_item

# --- 分析函数 ---
def analyze_crypto_text(text_blob, punctuation_table=None, letter_substitution_table=None):
    if punctuation_table is None:
        punctuation_table = {}
    if letter_substitution_table is None:
        letter_substitution_table = {}
        
    cleaned_text_orig = text_blob.replace("\n", "").replace(" ", "")

    # --- 第一阶段：应用标点符号替换 ---
    # punctuation_table 的值可能是 "L." 这样的字符串
    intermediate_text_chars = []
    for char_ci in cleaned_text_orig:
        # .get(char_ci, char_ci) 表示如果char_ci不在表中，则使用char_ci本身
        expanded_sequence = punctuation_table.get(char_ci, char_ci) 
        intermediate_text_chars.append(expanded_sequence)
    
    # 将所有替换后的序列连接起来形成中间文本
    text_to_analyze = "".join(intermediate_text_chars)
    text_length = len(text_to_analyze)

    if text_length == 0:
        print("错误：处理后文本为空。")
        return

    print(f"--- 文本分析开始 ---")
    print(f"原始密文 (清理后，前100字符): {cleaned_text_orig[:100]}...")
    # 为了清晰显示，可以将替换后的句号特殊标记一下，如果需要
    print(f"应用标点替换后文本 (前100字符): {text_to_analyze[:100].replace('.', '(.)')}...")
    print(f"标点替换后总长度: {text_length} 个字符\n")

    print(f"--- 当前标点替换表 (第一阶段) ---")
    if punctuation_table:
        for cipher_char, plain_char_seq in sorted(punctuation_table.items()):
            print(f"  '{cipher_char}' -> '{plain_char_seq}'")
    else:
        print("  (空)")
    print("")

    print(f"--- 当前字母替换表 (第二阶段，应用于上述文本) ---")
    if letter_substitution_table:
        for char_from_intermediate, plain_char in sorted(letter_substitution_table.items()):
            print(f"  '{char_from_intermediate}' -> '{plain_char}'")
    else:
        print("  (空，等待基于新频率构建)")
    print("")

    print("--- (0) 应用两阶段替换后的文本 (按原始大致结构预览) ---")
    # 预览逻辑：基于原始字符数进行分行，但显示的是两阶段替换后的内容
    preview_lines = []
    original_char_idx = 0
    num_rows_total = 13
    chars_per_line_default = 21
    missing_in_last_row = 4

    for r in range(num_rows_total):
        if original_char_idx >= len(cleaned_text_orig):
            break
        
        current_display_line_parts = []
        chars_in_this_original_line = chars_per_line_default
        if r == num_rows_total - 1:
            chars_in_this_original_line -= missing_in_last_row
        
        # 从原始文本中取字符，以确定该“原始格子”对应的内容
        for _ in range(chars_in_this_original_line):
            if original_char_idx >= len(cleaned_text_orig):
                break
            
            original_cipher_char = cleaned_text_orig[original_char_idx]
            
            # 第一阶段替换
            expanded_sequence = punctuation_table.get(original_cipher_char, original_cipher_char)
            
            # 第二阶段替换 (对第一阶段的结果中的每个字符进行)
            fully_substituted_sequence_parts = []
            for char_from_expanded in expanded_sequence: # 例如 G -> "A."，这里 char_from_expanded 会是 'A' 然后是 '.'
                final_char = letter_substitution_table.get(char_from_expanded, char_from_expanded)
                fully_substituted_sequence_parts.append(final_char)
            
            current_display_line_parts.append("".join(fully_substituted_sequence_parts))
            original_char_idx += 1
        
        if current_display_line_parts:
            preview_lines.append("".join(current_display_line_parts))

    for line_idx, line in enumerate(preview_lines):
        print(line)
        if line_idx >= 12 and original_char_idx < len(cleaned_text_orig): # 最多显示13行，如果还有则省略
            if r < num_rows_total -1:
                 print("...")
            break
    print("\n")

    # 分析函数现在使用 text_to_analyze (标点替换后的文本) 
    # 和 letter_substitution_table (第二阶段的字母替换)
    print_char_frequency(text_to_analyze, text_length, letter_substitution_table)
    analyze_ngrams(text_to_analyze, text_length, 2, "二元组 (Bigrams)", letter_substitution_table, min_freq_to_display=2)
    analyze_ngrams(text_to_analyze, text_length, 3, "三元组 (Trigrams)", letter_substitution_table, min_freq_to_display=2)
    analyze_ngrams(text_to_analyze, text_length, 4, "四元组 (Quadgrams)", letter_substitution_table, min_freq_to_display=2)
    analyze_ngrams(text_to_analyze, text_length, 5, "五元组 (Pentagrams)", letter_substitution_table, min_freq_to_display=2)
    find_significant_repeated_sequences(text_to_analyze, letter_substitution_table, min_len=3, max_len_to_check=15, min_repeats=2)
    
    print(f"--- 文本分析结束 ---")

def print_char_frequency(text_after_punctuation, text_length, letter_substitution_table):
    print("--- (1) 字符频率分析 (基于标点替换后的文本) ---")
    # text_after_punctuation 现在可能包含 '.' 等字符
    char_counts = collections.Counter(text_after_punctuation)
    sorted_char_counts = sorted(char_counts.items(), key=lambda item: (-item[1], item[0]))
    
    header_char = "符号(明文)" # "符号" 因为可能包含 '.'
    col_width_char = max(len(header_char), 7) # 调整列宽
    print(f"{header_char:<{col_width_char}} | {'出现次数':<8} | {'频率 (%)':<10}")
    print("-" * (col_width_char + 8 + 10 + 6))
    for char_from_intermediate, count in sorted_char_counts:
        # format_item_with_substitution 会尝试用 letter_substitution_table 替换 char_from_intermediate
        display_val = format_item_with_substitution(char_from_intermediate, letter_substitution_table)
        percentage = (count / text_length) * 100
        print(f"{display_val:<{col_width_char}} | {count:<8} | {percentage:>9.2f}%")
    print("\n")

def analyze_ngrams(text_after_punctuation, text_length, n_val, title, letter_substitution_table, min_freq_to_display=2):
    print(f"--- (2) {title} 频率分析 (基于标点替换后的文本, 出现次数 >= {min_freq_to_display}) ---")
    if text_length < n_val:
        print(f"文本长度 ({text_length}) 不足以生成 {n_val}元组。\n")
        return

    # N元组现在从包含句号的文本中生成，例如可能出现 "A." 这样的二元组
    ngrams_list = [text_after_punctuation[i:i+n_val] for i in range(text_length - n_val + 1)]
    ngram_counts = collections.Counter(ngrams_list)
    
    sorted_ngram_counts = sorted(
        [(ngram, count) for ngram, count in ngram_counts.items() if count >= min_freq_to_display],
        key=lambda item: (-item[1], item[0])
    )

    if not sorted_ngram_counts:
        print(f"未找到出现次数至少为 {min_freq_to_display} 次的 {n_val}元组。\n")
        return

    header_ngram = f'{n_val}元组(明文)'
    col_width_ngram = max(len(header_ngram), n_val * 2 + 7) # 增加列宽以适应 A.(t.) 这样的显示
    print(f"{header_ngram:<{col_width_ngram}} | {'出现次数':<8} | {'频率 (%)':<10}")
    print("-" * (col_width_ngram + 8 + 10 + 6))
    
    num_possible_ngrams = text_length - n_val + 1
    for ngram_intermediate, count in sorted_ngram_counts:
        # format_item_with_substitution 会尝试用 letter_substitution_table 替换 ngram_intermediate 中的每个字符
        display_ngram = format_item_with_substitution(ngram_intermediate, letter_substitution_table)
        percentage = (count / num_possible_ngrams) * 100 
        print(f"{display_ngram:<{col_width_ngram}} | {count:<8} | {percentage:>9.2f}%")
    print("\n")

def find_significant_repeated_sequences(text_after_punctuation, letter_substitution_table, min_len=3, max_len_to_check=15, min_repeats=2):
    n = len(text_after_punctuation)
    print(f"--- (3) 主要重复子序列分析 (基于标点替换后的文本, 长度 {min_len}-{max_len_to_check}, 出现次数 >= {min_repeats}) ---")

    if n == 0: print("文本为空。\n"); return
        
    all_substring_counts = collections.Counter()
    actual_max_len = min(max_len_to_check, n) 

    for length in range(min_len, actual_max_len + 1):
        if length > n: continue 
        for i in range(n - length + 1):
            all_substring_counts[text_after_punctuation[i:i+length]] += 1
    
    repeated_sequences = {s:c for s,c in all_substring_counts.items() if c >= min_repeats and len(s) >= min_len}
    if not repeated_sequences: print(f"未找到符合条件的重复序列。\n"); return

    sorted_by_len_desc = sorted(repeated_sequences.items(), key=lambda x: (-len(x[0]), -x[1], x[0]))
    final_dominant_repeats = {}
    for seq_intermediate, count in sorted_by_len_desc:
        is_sub = any(seq_intermediate in existing for existing in final_dominant_repeats)
        if not is_sub: final_dominant_repeats[seq_intermediate] = count
            
    if not final_dominant_repeats: print(f"筛选后未找到独立重复序列。\n"); return

    display_sorted = sorted(final_dominant_repeats.items(), key=lambda x: (-len(x[0]), -x[1], x[0]))
    
    header_seq = "子序列(明文)"
    col_width_seq = max(len(header_seq), actual_max_len * 2 + 7) 
    print(f"{header_seq:<{col_width_seq}} | {'长度':<6} | {'出现次数':<8}")
    print("-" * (col_width_seq + 6 + 8 + 6))
    for seq_intermediate, count in display_sorted:
        display_seq = format_item_with_substitution(seq_intermediate, letter_substitution_table)
        print(f"{display_seq:<{col_width_seq}} | {len(seq_intermediate):<6} | {count:<8}")
    print("\n")

# --- 主程序入口 ---
if __name__ == "__main__":
    decoded_text_from_image = """ABCDEFGHAFIJKDLMINNDO
PFHNPQLHIRPLSNPFDTAUA
FPIVICWBCHXKINHFBSRPC
HIYAFPQBLDZPRAIADBJKF
HNPAFPQNBH0RRDBCIMIRR
IRRDJNHHRPFDNHXKDLMHL
D1DCIAPFDTAB1BNNB2RFP
KDLMEUAUAFPKINHFBSRPI
CXVHZB1PAFP0DNRGQHNRB
JAUWDRZBOHYFD3ZBNQRPK
DA45RANBC6ILDV7AFHRPQ
BLDZPB00DZHN3IVRBLSAH
L8ZIJCBGINNHRGFHY"""

    # 第一阶段：用户提供的“密文 -> 字母+句号”的替换表
    punctuation_substitutions_from_user = {
        "G": "A.", "J": "C.", "M": "L.", "P": "H.", "Y": "N.", "U": "B.", "X": "W.", 
        "2": "K.", "T": "1.", "7": "D.", "6": "E.", "4": "F.", "5": "I.", "3": "R."
        # 注意：这里的键是原始密文字符，值是它们代表的“字母+句号”组合
    }

    # 第二阶段：新的字母替换表。
    # 这个表应该基于对第一阶段处理后的文本（现在包含A, ., C, ., H, .等）的频率分析来构建。
    # 对于这次运行，我们将其设置为空，以便你可以看到第一阶段替换后的纯粹结果和新的频率。
    new_letter_substitution_table = {'H': 'e', 'B': 'a', 'A': 't', 'D': 'o', 'N': 'i', 'R': 'n', 
    'F': 'h', 'I': 's', 'L': 'r', 'C': 'd', 'K': 'l', # 这是你上一轮的成果

    'Z': 'v',  # 新增
    'Q': 'f',  # 新增
    'W': 'c',  # 新增 (密文W)
    '1': 'u',  # 新增 
    '0': 'p',  # 新增 (密文0)
    'S': 'm',  # 新增 (密文S)
    'V': 'g',   # 新增 (密文V)
    "O": "y"
    }
   
    
    analyze_crypto_text(decoded_text_from_image, 
                        punctuation_table=punctuation_substitutions_from_user, 
                        letter_substitution_table=new_letter_substitution_table)