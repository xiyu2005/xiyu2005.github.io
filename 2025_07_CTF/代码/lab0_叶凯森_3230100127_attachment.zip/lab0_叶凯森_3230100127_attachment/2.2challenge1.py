import requests
import time
import re # 用于解析 token 和响应内容

# --- 配置区 ---
base_page_url = "http://pumpk1n.com/lab0.php"
# flag.php 的 URL 模板，token 将在脚本中动态填充
getflag_action_url_template = "http://pumpk1n.com/flag.php?token={token}"

# --- 结束配置区 ---

session = requests.Session()
# 设置请求头，模拟浏览器 (使用你之前提供的 User-Agent)
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
    "Referer": base_page_url,
    "Accept": "*/*", # 保持和你提供的请求头一致
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Connection": "keep-alive",
    "Host": "pumpk1n.com"
    # Cookie PHPSESSID 会由 session 自动管理
})

total_attempts_needed = 1337
final_alert_content = "" # 用于存储最后一次尝试的响应内容
last_successful_attempt = 0 # 用于记录最后一次成功完成的步骤是哪一步

print(f"🚀 准备开始自动化 {total_attempts_needed} 次尝试...")

for i in range(1, total_attempts_needed + 1):
    print(f"\n--- 尝试次数 #{i}/{total_attempts_needed} ---")
    last_successful_attempt = i - 1

    # 步骤 1: 刷新主页面 (lab0.php) 以获取新的 token
    current_token = None
    try:
        print(f"  [1] 正在刷新页面 ({base_page_url}) 以获取新 token...")
        refresh_response = session.get(base_page_url, timeout=15)
        refresh_response.raise_for_status() # 如果状态码不是 2xx，则抛出异常
        lab_page_content = refresh_response.text
        # print(f"      刷新成功，状态码: {refresh_response.status_code}")

        # 从 lab_page_content 中提取动态 token
        # 基于你的描述和提供的 HTML 结构，我们假设 token 在 getflag() 函数的 fetch 调用中
        # 正则表达式查找 fetch('/flag.php?token=xxxxxxxxxxxxxxxx') 这样的模式
        # ([0-9a-fA-F]{16}) 就是捕获组，用于提取16位的十六进制 token
        token_match = re.search(r"fetch\('/flag\.php\?token=([0-9a-fA-F]{16})'\)", lab_page_content)

        if token_match:
            current_token = token_match.group(1) # .group(1) 获取第一个捕获组的内容 (即 token)
            print(f"      🔑 Token 已提取: {current_token}")
        else:
            print(f"  [!] 错误: 在第 {i} 次尝试时，未能从 {base_page_url} 的内容中提取到 token。")
            print(f"      请检查 lab0.php 的实际 HTML 源代码，确认 token 的位置和提取逻辑是否正确。")
            print(f"      页面内容片段 (前 1000 字符): {lab_page_content[:1000]}")
            final_alert_content = f"在第 {i} 次尝试时未能提取到 token。"
            break # 提取 token 失败，终止脚本

    except requests.exceptions.RequestException as e:
        print(f"  [!] 错误: 在第 {i} 次尝试刷新页面或提取 token 时发生错误: {e}")
        final_alert_content = f"在第 {i} 次尝试刷新或提取 token 时发生错误: {e}"
        break

    if not current_token:
        break # 如果没有 token，则中断

    # (可选) 步骤间的短暂延迟
    # time.sleep(0.05) # 50毫秒

    # 步骤 2: 使用提取到的 token 向 flag.php 发送 GET 请求
    try:
        flag_request_url = getflag_action_url_template.format(token=current_token)
        print(f"  [2] 正在使用 token 请求 flag: {flag_request_url}")
        action_response = session.get(flag_request_url, timeout=15)
        action_response.raise_for_status()
        current_response_text = action_response.text.strip() # 获取响应文本并去除首尾空白
        # print(f"      Flag 请求成功，状态码: {action_response.status_code}")

        if i < total_attempts_needed:
            # 对于中间的尝试，我们期望看到类似 "one more time！当前次数/1337" 的内容
            expected_message_regex = rf"one more time！\s*{i}/{total_attempts_needed}"
            if re.search(expected_message_regex, current_response_text, re.IGNORECASE):
                 print(f"      💬 收到预期中间响应 (内容尾部): ...{current_response_text[-60:]}")
            else:
                print(f"  [!] 警告: 第 {i} 次尝试的响应与预期不符。")
                print(f"      收到: \"{current_response_text}\"")
                print(f"      预期应包含类似: \"one more time！{i}/{total_attempts_needed}\"")
        
        if i == total_attempts_needed:
            print(f"  [+] 🎉 这是第 {total_attempts_needed} 次尝试！正在记录最终响应内容。")
            final_alert_content = current_response_text
            last_successful_attempt = i # 记录这是最后一次成功的尝试
            # 循环将在这次迭代后自然结束

    except requests.exceptions.HTTPError as e:
        status_code_info = f"(状态码 {e.response.status_code})" if e.response else ""
        print(f"  [!] HTTP 错误: 在第 {i} 次 flag 请求期间发生 {status_code_info}: {e}")
        if e.response: print(f"      服务器响应内容 (部分): {e.response.text[:200]}...")
        final_alert_content = f"在第 {i} 次 flag 请求期间发生 HTTP 错误: {e}"
        break
    except requests.exceptions.RequestException as e:
        print(f"  [!] 请求错误: 在第 {i} 次 flag 请求期间发生: {e}")
        final_alert_content = f"在第 {i} 次 flag 请求期间发生请求错误: {e}"
        break
    
    # (可选) 每次完整循环（刷新+操作）之间的延迟
    if i < total_attempts_needed:
        # time.sleep(0.1) # 例如暂停0.1秒
        pass

print("\n--- 自动化过程结束 ---")
if final_alert_content:
    is_still_retry_message = "one more time" in final_alert_content.lower()
    
    if last_successful_attempt == total_attempts_needed and not is_still_retry_message:
        print(f"🏁 成功完成所有 {total_attempts_needed} 次尝试！")
        print("第 1337 次尝试后，服务器返回的（模拟 alert 的）最终内容是:")
        print("============================================================")
        print(final_alert_content)
        print("============================================================")
    elif last_successful_attempt == total_attempts_needed and is_still_retry_message:
        print(f"🏁 完成了所有 {total_attempts_needed} 次尝试，但最后一次响应似乎仍然是 'one more time'。")
        print("第 1337 次尝试的响应内容:")
        print("============================================================")
        print(final_alert_content)
        print("============================================================")
        print("请检查此内容是否包含flag，或者挑战逻辑可能与预期不同。")
    else: # 如果中途出错
        print(f"🛑 过程在第 {last_successful_attempt + 1} 次尝试时中断。")
        print("最后捕获到的响应或错误信息是:")
        print("============================================================")
        print(final_alert_content)
        print("============================================================")
else:
    print("🤷 未能捕获到最终响应内容。这可能表示在首次尝试前或过程中发生问题，或者最终响应为空。")