import socket
import re # 用于解析数学表达式

HOST = "10.214.160.13"  # IP address
PORT = 11002            # Port number

# 你的接收函数 (可以稍微改进一下错误处理和解码)
def recv_until(sock, delimiter_byte):
    buf = b""
    while True:
        data = sock.recv(1)
        if not data: # 服务器关闭了连接
            # 如果buf里有东西，可能是服务器在发送中途关闭了
            raise ConnectionError(f"Connection closed by peer while waiting for '{delimiter_byte.decode()}', received so far: {buf.decode(errors='ignore')}")
        buf += data
        if data == delimiter_byte:
            return buf[:-1] # 返回不包含分隔符的内容

def solve_expression(expression_str):
    """
    解析并计算数学表达式字符串。
    例如: "123+456" -> 579
    你需要实现这个函数！
    这只是一个非常简单的示例，可能无法处理所有情况（如负数、空格等）
    你需要根据实际题目进行调整。
    """
    print(f"  准备计算: {expression_str}")
    try:
        # 注意: eval() 有安全风险，但在CTF中通常用于计算服务器给的简单数学题
        # 如果题目复杂或者你不信任来源，需要用更安全的解析方式
        # 确保 expression_str 是纯粹的数学表达式
        # 为了安全，可以先用正则表达式检查一下表达式的格式
        if re.fullmatch(r"^\s*\d+\s*[\+\-\*\/]\s*\d+\s*$", expression_str): # 简单匹配 "数字 运算符 数字"
            answer = eval(expression_str)
            print(f"  计算结果: {int(answer)}")
            return str(int(answer)) # 确保是整数形式的字符串
        else:
            print(f"  无效的表达式格式: {expression_str}")
            # 这里可以尝试更复杂的解析，或者直接返回错误
            # 例如，直接去掉所有非数字和运算符的字符
            # cleaned_expression = re.sub(r'[^\d\+\-\*\/]', '', expression_str)
            # if cleaned_expression:
            #     answer = eval(cleaned_expression)
            #     return str(int(answer))
            raise ValueError("Invalid expression format for eval")
    except Exception as e:
        print(f"  计算出错: {e}")
        return "Error" # 或者抛出异常

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    print(f"正在连接 {HOST}:{PORT}...")
    s.connect((HOST, PORT))
    print("连接成功！")
    
    
    # 挑战要求完成10次计算
    for i in range(10): # 假设是10个问题
        print(f"\n--- 第 {i+1} 个问题 ---")
        
        # 1. 接收问题 (例如 "123+456=")
        question_bytes = recv_until(s, b'=')
        question_str = question_bytes.decode().strip()
        print(f"收到问题: {question_str}=")

        # 2. 计算答案
        answer_str = solve_expression(question_str)

        # 3. 发送答案 (例如 "579\n")
        s.sendall(answer_str.encode() + b"\n")
        print(f"发送答案: {answer_str}")

        # 4. 接收服务器对本次答案的反馈 (可能是 "Correct!\n", "Wrong!\n", 或者直接是下一个问题的前导信息，或者flag)
        #    如果服务器直接发送下一题，这行可能需要调整或删除
        #    我们先假设它会有一个简短的反馈或者至少一个换行
        response_bytes = recv_until(s, b'\n')
        response_str = response_bytes.decode().strip()
        print(f"服务器回应: {response_str}")

        if "flag" in response_str.lower() or "ctf" in response_str.lower(): # 简单判断是否是flag
            print("\n!!! 可能收到FLAG !!!")
            break
        if "wrong" in response_str.lower() or "error" in response_str.lower():
            print("答案错误或服务器报告错误，终止。")
            break
        if i == 9 and not ("flag" in response_str.lower() or "ctf" in response_str.lower()):
             # 如果是最后一个问题，并且回复不是flag，可以尝试多读一行看flag是否在下一行
            print("这是最后一个问题，尝试多读一行看看是不是flag...")
            try:
                final_response_bytes = recv_until(s, b'\n')
                final_response_str = final_response_bytes.decode().strip()
                print(f"额外读取内容: {final_response_str}")
            except ConnectionError as ce_final:
                print(f"尝试额外读取时连接已关闭: {ce_final}")
            except Exception as e_final:
                print(f"尝试额外读取时出错: {e_final}")


    # 所有问题回答完毕后，服务器可能会发送flag
    # 尝试再读取一次，看看是不是flag
    # 注意：上面的循环可能已经通过 "Correct!" 之外的响应获取了flag
    print("\n尝试读取最终的Flag...")
    try:
        # 一直读取直到连接关闭或收到包含flag的内容
        final_data = b""
        while True:
            chunk = s.recv(1024)
            if not chunk:
                break # 连接已关闭
            final_data += chunk
            # 你可能需要在这里解码并检查 final_data 是否包含 flag
            # 为了简单起见，我们先全部接收
            # print(f"收到数据块: {chunk.decode(errors='ignore')}")
            if b"flag" in final_data.lower() or b"ctf" in final_data.lower(): # 假设flag不区分大小写
                 break
        
        print(f"最终收到数据: {final_data.decode(errors='ignore')}")

    except ConnectionError as ce: # recv_until 可能会抛出这个
        print(f"读取最终数据时连接错误: {ce}")
    except Exception as e:
        print(f"读取最终数据时发生错误: {e}")

except socket.error as e:
    print(f"Socket 错误: {e}")
except ConnectionError as e: # Handle ConnectionError from recv_until
    print(f"连接错误: {e}")
except Exception as e:
    print(f"其他错误: {e}")
finally:
    print("关闭socket。")
    s.close()