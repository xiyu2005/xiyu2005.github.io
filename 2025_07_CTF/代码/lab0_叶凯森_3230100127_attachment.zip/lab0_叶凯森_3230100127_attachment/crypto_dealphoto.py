from PIL import Image
import hashlib
import os
def solve_image_cipher(image_path):
    """
    破解图片中的信息。

    Args:
        image_path (str): 图片文件的路径。

    Returns:
        str: 破解后的信息。
        dict: 图案哈希值到分配字符的映射。
        int: 唯一图案的数量。
    """
    try:
        img = Image.open(image_path).convert('RGB') # 确保是RGB模式
    except FileNotFoundError:
        return "错误：图片文件未找到。", {}, 0
    except Exception as e:
        return f"错误：加载图片失败 - {e}", {}, 0

    img_width, img_height = img.size

    # 根据题目信息计算
    cols = 21
    rows = 13
    missing_in_last_row = 4

    # 自动计算或手动设置单个图案的尺寸
    # 如果图案之间有间隙，这里的计算可能需要微调
    char_width = img_width // cols
    char_height = img_height // rows

    print(f"图片尺寸: {img_width}x{img_height}")
    print(f"推断的单个图案尺寸: {char_width}x{char_height}")
    if char_width != 64 or char_height != 64:
        print("警告：计算出的图案尺寸与预期 (64x64) 不符，请检查图片或参数。")


    pictograms_data = [] # 存储切割下来的图案数据
    pictogram_hashes = [] # 存储每个图案的哈希值

    total_pictograms_expected = (rows * cols) - missing_in_last_row
    count = 0

    for r in range(rows):
        for c in range(cols):
            if r == rows - 1 and c >= cols - missing_in_last_row:
                # 跳过最后一行缺失的图案
                continue

            # 定义切割区域 (left, top, right, bottom)
            # left = c * char_width
            # top = r * char_height
            # right = left + char_width
            # bottom = top + char_height

            # 尝试居中裁剪，如果图案小于单元格
            # 如果图案严格按照格子划分，不需要偏移
            cell_left = c * char_width
            cell_top = r * char_height
            
            # 假设图案就在单元格内，大小为char_width x char_height
            # 如果实际图案比这个小且在单元格内居中，需要更复杂的定位
            # 但基于“规整的图画”，我们先假设它们填满了单元格
            left = cell_left
            top = cell_top
            right = cell_left + char_width
            bottom = cell_top + char_height


            # 切割图案
            try:
                pictogram = img.crop((left, top, right, bottom))
                pictograms_data.append(pictogram)
                
                # 为图案生成哈希值以识别唯一性
                # 将图像数据转换为字节串进行哈希
                hasher = hashlib.md5()
                hasher.update(pictogram.tobytes())
                pictogram_hashes.append(hasher.hexdigest())
                count += 1
            except Exception as e:
                print(f"错误：在位置 ({r},{c}) 切割图案失败 - {e}")
                # 可以选择跳过这个图案或者中断
                continue
    
    print(f"成功切割了 {count} 个图案，预期 {total_pictograms_expected} 个。")
    if count != total_pictograms_expected:
        print("警告：实际切割的图案数量与预期不符，请检查逻辑或图片。")


    # 建立哈希值到字符的映射
    unique_hashes = []
    for h in pictogram_hashes:
        if h not in unique_hashes:
            unique_hashes.append(h)

    # 你可以使用任何你喜欢的字符集，这里用大写字母，然后是数字等
    # 如果唯一图案超过了字符集大小，需要扩展字符集
    possible_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz@#$%^&*"
    
    hash_to_char_map = {}
    if len(unique_hashes) > len(possible_chars):
        print(f"警告：唯一图案数量 ({len(unique_hashes)}) 大于预定义字符集 ({len(possible_chars)})。部分图案将无法分配字符。")
        # 可以考虑生成更长的字符序列或提示用户
        # for i in range(len(unique_hashes) - len(possible_chars)):
        #     possible_chars += f'_{i}' # 简单扩展

    for i, h_val in enumerate(unique_hashes):
        if i < len(possible_chars):
            hash_to_char_map[h_val] = possible_chars[i]
        else:
            # 如果字符不够用，给一个特殊标记或者序号
            hash_to_char_map[h_val] = f"[UNMAPPED_{i-len(possible_chars)}]"


    # 解码信息
    decoded_message = ""
    pictograms_in_row = 0
    for h_val in pictogram_hashes:
        decoded_message += hash_to_char_map.get(h_val, "?") # 如果哈希值未找到映射（理论上不应发生），用?代替
        pictograms_in_row += 1
        if pictograms_in_row == cols:
            decoded_message += "\n" # 每行结束后换行
            pictograms_in_row = 0
    
    # 移除因最后一行不足而产生的多余换行符
    if pictograms_in_row != 0 and decoded_message.endswith("\n"):
         # 如果最后一行不是满的，上面的逻辑会在该行结束后也加换行符，但如果这就是文本的结尾，就不需要额外处理。
         # 如果是严格按照原图的行列结构展示，那么最后一个换行符可能是需要的。
         # 但如果只是想得到连续的字符流，则可能需要处理。
         # 这里我们假设解码后的信息也按行显示。
         pass


    return decoded_message.strip(), hash_to_char_map, len(unique_hashes)

# --- 主程序 ---
if __name__ == "__main__":
    # 请将 "YOUR_IMAGE_PATH.png" 替换为你的图片文件路径
    # 例如: image_file = "path/to/your/image.png"
    # 初始化 image_file 为一个默认值或占位符
    image_file = "crypto_challenge1.png" 

    # 为了测试，我们可以先创建一个虚拟的符合描述的图片
    # (实际使用时请注释或删除这段创建虚拟图片的代码)
    # try:
    #     # 尝试导入 Pillow 和 ImageDraw 是创建虚拟图片的前提
    #     from PIL import Image, ImageDraw 

    #     test_img_width = 1344
    #     test_img_height = 832
    #     test_cols = 21
    #     test_rows = 13
    #     missing_in_last_row = 4 # 题目中是少四个
        
    #     dummy_image = Image.new('RGB', (test_img_width, test_img_height), color = 'white')
    #     draw = ImageDraw.Draw(dummy_image)
    #     char_w, char_h = test_img_width // test_cols, test_img_height // test_rows
    #     colors = [(255,0,0), (0,255,0), (0,0,255), (255,255,0), (0,255,255)]
        
    #     for r_idx in range(test_rows):
    #         for c_idx in range(test_cols):
    #             if r_idx == test_rows -1 and c_idx >= test_cols - missing_in_last_row:
    #                 continue
    #             x0, y0 = c_idx * char_w, r_idx * char_h
    #             x1, y1 = x0 + char_w, y0 + char_h
    #             current_color = colors[ (r_idx * test_cols + c_idx) % len(colors) ]
    #             draw.rectangle([x0, y0, x1, y1], fill=current_color)
    #             if (r_idx + c_idx) % 2 == 0:
    #                  draw.rectangle([x0+char_w//4, y0+char_h//4, x1-char_w//4, y1-char_h//4], fill=(255,255,255) if sum(current_color) > 255 else (0,0,0))

    #     dummy_image.save("dummy_cipher_image.png")
    #     image_file = "dummy_cipher_image.png" # 成功创建并保存虚拟图片，更新 image_file
    #     print("已生成一个虚拟测试图片: dummy_cipher_image.png")

    # except ImportError:
    #     print("警告：未能导入 Pillow 或 ImageDraw，无法创建虚拟测试图片。请确保Pillow已正确安装。")
    #     # image_file 保持为 "YOUR_IMAGE_PATH.png"
    # except Exception as e_create:
    #     print(f"创建虚拟图片时出错: {e_create}")
    #     # image_file 保持为 "YOUR_IMAGE_PATH.png"

    # --- 后续代码不变 ---
    if image_file == "YOUR_IMAGE_PATH.png":
        print(f"\n请将脚本中的 'image_file' 变量手动更改为你的图片路径，或者确保虚拟图片生成部分正常工作。")
        # 如果希望在图片路径未设置时退出，可以添加 exit()
        # exit() 
    
    # 只有当 image_file 不是占位符时才继续执行
    if image_file != "YOUR_IMAGE_PATH.png" or os.path.exists(image_file): # 添加一个检查，确保文件存在
        # 检查文件是否存在，如果不存在且不是dummy，则提示
        if not os.path.exists(image_file) and image_file != "dummy_cipher_image.png":
             print(f"错误：图片文件 {image_file} 未找到！请检查路径。")
        else:
            message, char_map, unique_count = solve_image_cipher(image_file)

            print("\n--- 破解结果 ---")
            if "错误：" in message:
                print(message)
            else:
                print(f"唯一图案数量: {unique_count}")
                print("\n解码后的信息 (按原始行列布局):")
                print(message)
    else:
        # 如果 image_file 仍然是 "YOUR_IMAGE_PATH.png" 且没有生成dummy图，这里会执行
        # 之前已经打印过提示了，所以这里可能不需要额外操作，或者可以明确退出
        pass

            # 如果想查看更详细的映射关系
            # print("\n详细映射 (哈希值 -> 字符):")
            # for h_val, char_val in char_map.items():
            #     print(f"{h_val} -> {char_val}")