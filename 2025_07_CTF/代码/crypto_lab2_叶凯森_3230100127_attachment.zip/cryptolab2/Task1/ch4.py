from Crypto.Util.number import inverse, long_to_bytes

def main():
    # --- 静态加载 Challenge 4 的所有参数 ---
    e_hex = '10001'
    n_hex = '81a8a5d31d394cf22be1279821b393cf40fc50bfee4720c5a37d4adcca081733d4386a528d156db3c8e9a464c1d16057e656af4fd9b23ec162b2732758646f62c7349ddf384d415b177e7e4f9177d381da8ba389ea19c86baad6d4e18095cdb8221117260d7bb790bc8b5a8902022dc4f4614be72709d382be0f185ed474805b'
    dp_hex = '46b50ee343445e826f0405f22a61902efeed47dd29e69b351ccb0e7d6377981c29dc6277a98934375f50de7309299fe92772110f855ee0d3af948185ee473c17'
    c_hex = '4e51c96b8bd862128c125d67588f7d3b9bb32c4ca45d37e4d18e378588d83e7f73b346a483ea89385d5c503d2e4e48d4b1f001c6d4de1ddbd3ddb5289665db64033cf236ed8c2da55e7410411904d8e3f523789871c7a91f145c52ad2e74ab36e59565250946a9fc8bf77d81a0a24a20f8743e4ee84da43d385eed33fe948224'

    e = int(e_hex, 16)
    n = int(n_hex, 16)
    dp = int(dp_hex, 16)
    c = int(c_hex, 16)

    print("[*] Challenge 4: dp 泄露攻击")
    print(f"    e = {e}")
    print(f"    n = {hex(n)}")

    # --- 1. 通过爆破 k 来分解 n ---
    print("\n[*] 正在搜索 k in e*dp - 1 = k*(p-1)...")
    p, q = 0, 0
    multiple = e * dp - 1
    
    # 扩大 k 的搜索范围，一个常见的技巧是 k 可能等于 e
    # 我们搜索到 e+10 确保能覆盖到
    for k in range(1, e + 10):
        if multiple % k == 0:
            p_candidate = (multiple // k) + 1
            # 检查候选p是否为n的因子
            if p_candidate > 1 and n % p_candidate == 0:
                p = p_candidate
                q = n // p
                print(f"[+] 成功找到因子! k = {k}")
                print(f"    p = {p}")
                print(f"    q = {q}")
                break

    if p == 0:
        print("[-] 在扩大的范围内仍然未能分解 n。")
        return

    # --- 2. 标准RSA解密 ---
    print("\n[*] 正在执行标准RSA解密...")
    phi = (p - 1) * (q - 1)
    d = inverse(e, phi)
    m = pow(c, d, n)
    print("[+] 解密成功。")

    # --- 3. 按要求进行双重验证 ---
    print("\n[*] 正在执行最终验证...")
    # 验证 dp
    dp_calculated = d % (p - 1)
    assert dp == dp_calculated, f"dp 验证失败! 得到 {dp_calculated}, 期望 {dp}"
    print("    [✓] assert dp == d%(p-1)  -- 验证通过")

    # 验证明文
    assert pow(m, e, n) == c, "明文验证失败!"
    print("    [✓] assert c == pow(m, e, n) -- 验证通过")

    # --- 4. 输出最终结果 ---
    print("\n" + "="*50)
    print(f"最终明文 m (十进制): {m}")
    m_hex = hex(m)[2:]
    print(f"用于提交的HEX字符串: {m_hex}")
    print("="*50)

if __name__ == '__main__':
    main()