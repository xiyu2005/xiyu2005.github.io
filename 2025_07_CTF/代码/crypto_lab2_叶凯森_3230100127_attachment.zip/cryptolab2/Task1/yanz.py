import sys

def hex_to_decimal():
    """
    将用户输入的十六进制字符串转换为十进制整数。
    支持命令行参数或交互式输入。
    """
    if len(sys.argv) > 1:
        hex_str = sys.argv[1]
    else:
        hex_str = input("请输入十六进制数（如：1A、0xff）：").strip()

    try:
        decimal_value = int(hex_str, 16)
        print(f"十进制值为：{decimal_value}")
    except ValueError:
        print("⚠️ 错误：请输入有效的十六进制数。")

if __name__ == "__main__":
    hex_to_decimal()