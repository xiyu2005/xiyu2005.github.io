from Crypto.Util.number import inverse, long_to_bytes

def main():
    # 1. 题目参数
    c_hex = '11dd44aa09c128e11487653cbf394a745e749b7401456ff7bd67af4de356'
    e = 3
    n_hex = '4a471ffda8b4d8d223f6b64884b798a8a8356e6d024f92c46a9171c8841b'
    
    # 2. 修正后的质因数 (n = p² * q)
    p = 800336709776908303690799
    q = 800336709776908303691579
    
    # 3. 验证分解正确性
    n_given = int(n_hex, 16)
    n_calc = p * p * q
    assert n_calc == n_given, "错误：计算出的n与题目n不匹配！"
    print(f"[*] 验证成功：n = p² * q (p={p}, q={q})")
    
    # 4. 验证互质性 (关键！)
    print("[*] 验证 gcd(e, φ(n)) = 1...")
    phi_n = p * (p - 1) * (q - 1)
    
    # 检查 p 和 q 模 3 的值
    p_mod3 = p % 3
    q_mod3 = q % 3
    print(f"    p % 3 = {p_mod3}, q % 3 = {q_mod3}")
    
    # 由于 p % 3 = 2, q % 3 = 2 → p-1 % 3 = 1, q-1 % 3 = 1
    # 因此 φ(n) = p(p-1)(q-1) % 3 = 2 * 1 * 1 = 2 → 不被 3 整除
    assert math.gcd(e, phi_n) == 1, "错误：e 与 φ(n) 不互质！"
    print("[+] 验证通过：gcd(3, φ(n)) = 1")

    # 5. 计算私钥 d
    print("[*] 计算私钥 d = e⁻¹ mod φ(n)...")
    d = inverse(e, phi_n)
    print(f"[+] d = {d}")

    # 6. 解密
    c = int(c_hex, 16)
    print("[*] 解密中: m = cᵈ mod n...")
    m = pow(c, d, n_given)
    print(f"[+] 解密成功！m = {m}")

    # 7. 最终验证
    print("\n[+] 验证: pow(m, e, n) == c")
    assert pow(m, e, n_given) == c, "验证失败！"
    print("    [✓] 验证通过")

    # 8. 输出结果
    m_hex = hex(m)[2:]
    print(f"\n明文 (HEX): {m_hex}")
    print(f"明文 (ASCII): {long_to_bytes(m).decode('utf-8', 'ignore')}")

if __name__ == '__main__':
    import math
    main()