#!/usr/bin/env python3
from pwn import *
import hashlib
import string
import itertools
import re
from Crypto.Util.number import long_to_bytes, bytes_to_long, inverse
import gmpy2
import sympy

# --- 配置 ---
context.log_level = 'info'
HOST = '10.214.160.13'
PORT = 12601

# --- PoW 求解函数 ---
def solve_pow(suffix, target_hash):
    log.info(f"开始计算 PoW, 后缀: '{suffix}', 目标哈希: '{target_hash[:10]}...'")
    charset = string.ascii_letters + string.digits
    for p in itertools.product(charset, repeat=4):
        xxxx = "".join(p)
        if hashlib.sha256((xxxx + suffix).encode()).hexdigest() == target_hash:
            log.success(f"成功找到 XXXX: {xxxx}")
            return xxxx
    log.failure("未能在指定字符集和长度内找到解。")
    return None

# --- 中国剩余定理 (CRT) 求解函数 ---
def chinese_remainder_theorem(remainders, moduli):
    N = 1; result = 0
    for n_i in moduli: N *= n_i
    for c_i, n_i in zip(remainders, moduli):
        N_i = N // n_i; inv_N_i = inverse(N_i, n_i); result += c_i * N_i * inv_N_i
    return result % N

# --- 主逻辑 ---
def main():
    io = remote(HOST, PORT)
    try:
        # --- 阶段一: PoW ---
        io.recvuntil(b"sha256(XXXX + '")
        suffix = io.recvuntil(b"'", drop=True).decode()
        io.recvuntil(b"== ")
        target_hash = io.recvline().strip().decode()
        solution = solve_pow(suffix, target_hash)
        if not solution: io.close(); return
        io.sendlineafter(b": ", solution.encode())

        # --- 阶段二: Challenge 1 (CRT) ---
        log.info("解决 Challenge 1...")
        challenge1_data = io.recvuntil(b'[-] m = ', timeout=10).decode()
        c1 = int(re.search(r'c1 = (0x[0-9a-f]+)', challenge1_data).group(1), 16); n1 = int(re.search(r'n1 = (0x[0-9a-f]+)', challenge1_data).group(1), 16)
        c2 = int(re.search(r'c2 = (0x[0-9a-f]+)', challenge1_data).group(1), 16); n2 = int(re.search(r'n2 = (0x[0-9a-f]+)', challenge1_data).group(1), 16)
        c3 = int(re.search(r'c3 = (0x[0-9a-f]+)', challenge1_data).group(1), 16); n3_c1 = int(re.search(r'n3 = (0x[0-9a-f]+)', challenge1_data).group(1), 16)
        m1_cubed = chinese_remainder_theorem([c1, c2, c3], [n1, n2, n3_c1])
        m1, _ = gmpy2.iroot(m1_cubed, 3)
        io.sendline(hex(m1)[2:].encode())

        # --- 阶段三: Challenge 2 (e-th Root) ---
        log.info("解决 Challenge 2...")
        challenge2_data = io.recvuntil(b'[-] m = ', timeout=10).decode()
        p_c2 = int(re.search(r'p = (0x[0-9a-f]+)', challenge2_data).group(1), 16); q_c2 = int(re.search(r'q = (0x[0-9a-f]+)', challenge2_data).group(1), 16)
        e2 = int(re.search(r'e = (0x[0-9a-f]+)', challenge2_data).group(1), 16); c2_val = int(re.search(r'c = (0x[0-9a-f]+)', challenge2_data).group(1), 16)
        roots_p = sympy.nthroot_mod(c2_val, e2, p_c2, all_roots=True)
        roots_q = sympy.nthroot_mod(c2_val, e2, q_c2, all_roots=True)
        found_m2 = False
        for m_p in roots_p:
            for m_q in roots_q:
                candidate_m2 = chinese_remainder_theorem([m_p, m_q], [p_c2, q_c2])
                if 1 < candidate_m2.bit_length() <= 510:
                    io.sendline(hex(candidate_m2)[2:].encode()); found_m2 = True; break
            if found_m2: break
        if not found_m2: log.error("未能找到 Challenge 2 的解!"); io.close(); return
            
        # --- 阶段四: Challenge 3 (n = p² * q) ---
        log.info("解决 Challenge 3...")
        challenge3_data = io.recvuntil(b'[-] m = ', timeout=10).decode()
        e3 = int(re.search(r'e = (0x[0-9a-f]+)', challenge3_data).group(1), 16); n3 = int(re.search(r'n = (0x[0-9a-f]+)', challenge3_data).group(1), 16)
        c3 = int(re.search(r'c = (0x[0-9a-f]+)', challenge3_data).group(1), 16)
        p3 = 800336709776908303690799; q3 = 800336709776908303691579
        assert n3 == p3 * p3 * q3
        phi3 = p3 * (p3 - 1) * (q3 - 1); d3 = inverse(e3, phi3); m3 = pow(c3, d3, n3)
        io.sendline(hex(m3)[2:].encode())

        # --- 阶段五: Challenge 4 (dp Attack) ---
        log.info("解决 Challenge 4...")
        challenge4_data = io.recvuntil(b'[-] m = ', timeout=10).decode()
        e4 = int(re.search(r'e = (0x[0-9a-f]+)', challenge4_data).group(1), 16); n4 = int(re.search(r'n = (0x[0-9a-f]+)', challenge4_data).group(1), 16)
        dp4 = int(re.search(r'dp = (0x[0-9a-f]+)', challenge4_data).group(1), 16); c4 = int(re.search(r'c = (0x[0-9a-f]+)', challenge4_data).group(1), 16)
        p4, q4 = 0, 0; multiple = e4 * dp4 - 1
        for k in range(1, e4 + 10):
            if multiple % k == 0:
                p_candidate = (multiple // k) + 1
                if p_candidate > 1 and n4 % p_candidate == 0:
                    p4 = p_candidate; q4 = n4 // p_candidate; break
        if p4 == 0: log.error("未能分解 n!"); io.close(); return
        phi4 = (p4 - 1) * (q4 - 1); d4 = inverse(e4, phi4); m4 = pow(c4, d4, n4)
        io.sendline(hex(m4)[2:].encode())

        # --- 最终阶段: Challenge 5 (代数预言机攻击) ---
        log.info("解决最终挑战 Challenge 5...")
        challenge5_data = io.recvuntil(b'your choice: ', timeout=10).decode()
        n5 = int(re.search(r'n = (0x[0-9a-f]+)', challenge5_data).group(1), 16)
        
        log.info("第一次查询: k=1")
        io.sendline(b'1')
        io.sendlineafter(b'your k(hex): ', b'1')
        io.recvuntil(b'[+] result = ')
        c1_c5_hex = io.recvline().strip().decode()
        c1_c5 = int(c1_c5_hex, 16)
        log.success(f"获取到 C₁ = {c1_c5_hex}")
        
        log.info("第二次查询: k=2")
        io.sendlineafter(b'your choice: ', b'1')
        io.sendlineafter(b'your k(hex): ', b'2')
        io.recvuntil(b'[+] result = ')
        c2_c5_hex = io.recvline().strip().decode()
        c2_c5 = int(c2_c5_hex, 16)
        log.success(f"获取到 C₂ = {c2_c5_hex}")
        
        log.info("开始代数求解 m...")
        term1 = (c2_c5 + pow(c1_c5, 2, n5) - 2 * c1_c5 + n5) % n5
        term2 = inverse(2 * c1_c5 - 1, n5)
        y = (term1 * term2) % n5
        m5 = (y - c1_c5 + n5) % n5
        log.success(f"成功解出 m = {m5}")
        
        assert (m5 * (m5 + 1)) % n5 == c1_c5, "k=1 验证失败！"
        assert pow((m5 * (m5 + 2)) % n5, 2, n5) == c2_c5, "k=2 验证失败！"
        log.success("验证通过！")
        
        # 提交最终答案
        log.info("提交最终答案...")
        io.sendlineafter(b'your choice: ', b'2')
        
        # --- 已修正的部分 ---
        # 之前: io.sendlineafter(b'm = ', str(m5).encode())
        # 现在:
        m5_hex_submission = hex(m5)[2:]
        log.info(f"发送HEX格式的最终答案: {m5_hex_submission}")
        io.sendlineafter(b'm = ', m5_hex_submission.encode())
        # --- 修正结束 ---
        
        log.success("所有挑战已自动完成，Flag应该就在下方:")
        io.interactive()

    except Exception as e:
        log.error(f"发生错误: {e}")
        import traceback; traceback.print_exc()
    finally:
        if 'io' in locals() and io.connected(): io.close()

if __name__ == "__main__":
    main()