import sys
import math

# 设置一个高的整数到字符串转换限制
sys.set_int_max_str_digits(0)

## ----------------------------------------------------------------
## 1. 定义所有已知信息
## ----------------------------------------------------------------
print("--- 1. 定义已知信息 ---")
n_hex = "0xb3eaacc65bf88213e2a641130ae0c382fb2682794e62385f9944f9ff7356bbe2b057226747f38e177cb758888297c7f843f95dda1f5831d2e8ce48256604d11b45fc9010cbd183ee646bf6c687792284bbf029b7abc9e53b87d66a9ef15dd982ac7fa73d99fdd6baaf512bd735b64e2fb2ca29d2bc2e250ae2f9322ece30424b"
c1_hex = " 0xdf975432289097183712b38ac81aae0a369a7aabc2abb2ac6ba33411ce073693e4308a3a4685e49563d55875757a26e6fa6d15552c60e9cb58fecb3ba66a64c8432b36a20e014a96ef126ff9a5d67f605ed7553c6f752c0d605061f3f9aa735d985bae121d12d97fbb818346ec77929ed9e4a8c656aa4aa45b94581f65d1532"
c2_hex = "0xa8d2bd85b3962f2f6160ba8973084e2cd44837d72ca3db9456a6a1edf9ea9246b3765dbc309e9e37eabad16506953c0dccec051ec637fd7bba631b7d868b30b7a4c4f48075a296be1ec1aa5c770f0fb0a881bcd47e36924ecf1c9eeba47afa15ba34e69b4b6ebb704a14d8cd229af3989221d274d498dbe5c79a4fa437b26e79"

n = int(n_hex, 16)
c1 = int(c1_hex, 16)
c2 = int(c2_hex, 16)
print("   n, C₁, C₂ 已加载。\n")

## ----------------------------------------------------------------
## 2. 代数求解 sqrt(C₂)
## ----------------------------------------------------------------
print("--- 2. 代数求解 y = sqrt(C₂) ---")

# 计算 y = (C₂ + C₁² - 2C₁) * inv(2C₁ - 1) mod n
term1 = (c2 + pow(c1, 2, n) - 2 * c1 + n) % n
term2 = pow(2 * c1 - 1, -1, n)
y = (term1 * term2) % n

print(f"   [SUCCESS] 通过代数方法成功计算出 y = sqrt(C₂)!")
print(f"   y = sqrt(C₂) = {hex(y)}\n")

## ----------------------------------------------------------------
## 3. 计算 m
## ----------------------------------------------------------------
print("--- 3. 计算 m = (y - C₁) mod n ---")
m = (y - c1 + n) % n
print(f"   m 已计算。\n")

## ----------------------------------------------------------------
## 4. 显示最终答案
## ----------------------------------------------------------------
print("--- 4. 最终答案 ---")
print(f"[*] m (hex): {hex(m)}")
print(f"[*] m (dec): {m}\n")

## ----------------------------------------------------------------
## 5. 验证
## ----------------------------------------------------------------
print("--- 5. 验证 ---")

# 验证 k=1
print("[*] 正在验证 k=1...")
verify_k1 = (m * (m + 1)) % n
print(f"   计算值: {hex(verify_k1)}")
print(f"   期望值: {hex(c1)}")
if verify_k1 == c1:
    print("   ✅ [SUCCESS] k=1 验证通过！")
else:
    print("   ❌ [FAILURE] k=1 验证失败！")

# 验证 k=2
print("\n[*] 正在验证 k=2...")
base_k2 = (m * (m + 2)) % n
verify_k2 = pow(base_k2, 2, n)
print(f"   计算值: {hex(verify_k2)}")
print(f"   期望值: {hex(c2)}")
if verify_k2 == c2:
    print("   ✅ [SUCCESS] k=2 验证通过！")
else:
    print("   ❌ [FAILURE] k=2 验证失败！")