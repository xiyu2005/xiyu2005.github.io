import sys

# --- 椭圆曲线参数 ---
# 素数域的模数 p
p = 15424654874903
# 曲线方程 y^2 = x^3 + ax + b 的系数 a
a = 16546484
# 曲线方程的系数 b
b = 4548674875
# 基点 (生成元) G
G = (6478678675, 5636379357093)
# 私钥 k
private_key = 546768

# 定义无穷远点 O (群的单位元)
O = None

def modular_inverse(n, modulus):
    """
    计算 n 在模 modulus 下的乘法逆元。
    该函数使用了 Python 3.8+ 中 pow(n, -1, modulus) 的高效实现。
    """
    # 检查 Python 版本，为旧版本提供备用方案
    if sys.version_info < (3, 8):
        # 使用扩展欧几里得算法为旧版本 Python 计算模逆元
        g, x, y = egcd(n, modulus)
        if g != 1:
            raise Exception('模逆元不存在')
        return x % modulus
    return pow(n, -1, modulus)

def egcd(a, b):
    """扩展欧几里得算法"""
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)


def point_add(P, Q):
    """
    在椭圆曲线上执行点相加操作 (P + Q)。
    """
    # 处理无穷远点的情况
    if P == O:
        return Q
    if Q == O:
        return P

    x1, y1 = P
    x2, y2 = Q

    # 如果两个点的 x 坐标相同但 y 坐标不同，它们互为逆元，结果是无穷远点
    if x1 == x2 and y1 != y2:
        return O

    # 如果两个点相同，则执行点倍增
    if x1 == x2:
        return point_double(P)
    
    # --- P != Q 的情况 ---
    # 计算斜率 m = (y2 - y1) / (x2 - x1)
    # 分子
    m_num = (y2 - y1) % p
    # 分母的模逆元
    m_den = modular_inverse((x2 - x1) % p, p)
    # 斜率 m
    m = (m_num * m_den) % p

    # 计算新点的坐标
    # x3 = m^2 - x1 - x2
    x3 = (m * m - x1 - x2) % p
    # y3 = m(x1 - x3) - y1
    y3 = (m * (x1 - x3) - y1) % p

    return (x3, y3)

def point_double(P):
    """
    在椭圆曲线上执行点倍增操作 (2 * P)。
    """
    if P == O:
        return O

    x1, y1 = P

    # 如果 y1 是 0，切线是垂直的，结果是无穷远点
    if y1 == 0:
        return O

    # --- 计算切线斜率 m = (3*x1^2 + a) / (2*y1) ---
    # 分子
    m_num = (3 * x1 * x1 + a) % p
    # 分母的模逆元
    m_den = modular_inverse((2 * y1) % p, p)
    # 斜率 m
    m = (m_num * m_den) % p

    # 计算新点的坐标
    # x3 = m^2 - 2*x1
    x3 = (m * m - 2 * x1) % p
    # y3 = m(x1 - x3) - y1
    y3 = (m * (x1 - x3) - y1) % p

    return (x3, y3)

def scalar_multiply(k, P):
    """
    执行标量乘法 (k * P)，也称点乘。
    采用从左到右的 "Double-and-Add" 算法。
    """
    # 获取 k 的二进制表示，并去掉 '0b' 前缀
    k_bin = bin(k)[2:]
    
    # 初始化结果为基点 P
    current_point = P
    
    # 从二进制的第二位开始遍历
    for bit in k_bin[1:]:
        # 对当前点进行倍增
        current_point = point_double(current_point)
        # 如果当前位是 '1'，则再与基点 P 相加
        if bit == '1':
            current_point = point_add(current_point, P)
            
    return current_point

# --- 主计算流程 ---
if __name__ == "__main__":
    print("正在计算公钥 K = k * G ...")
    
    # 调用标量乘法函数计算公钥
    public_key = scalar_multiply(private_key, G)

    if public_key is not None:
        Kx, Ky = public_key
        print("\n计算完成！")
        print("="*30)
        print(f"公钥 K(x, y):")
        print(f"  x = {Kx}")
        print(f"  y = {Ky}")
        
        # 计算 flag 需要的值
        flag_value = Kx + Ky
        print(f"\nflag 值 (x + y): {flag_value}")
        
        # 格式化输出最终的 flag
        flag = f"cyberpeace{{{flag_value}}}"
        print(f"\n最终 Flag: {flag}")
        print("="*30)
    else:
        print("计算错误：结果为无穷远点。")