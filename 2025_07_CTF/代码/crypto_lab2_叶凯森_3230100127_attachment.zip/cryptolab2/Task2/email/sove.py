import re
import itertools
from Crypto.Util.number import long_to_bytes

def modinv(a, m):
    try:
        return pow(a, -1, m)
    except ValueError:
        raise Exception('Modular inverse does not exist')

def solve_crt(remainders, moduli):
    N_total = 1
    for n in moduli:
        N_total *= n
    result = 0
    for i in range(len(moduli)):
        c_i, N_i = remainders[i], moduli[i]
        N_prod_i = N_total // N_i
        inv_i = modinv(N_prod_i, N_i)
        result += c_i * N_prod_i * inv_i
    return result % N_total

def integer_cbrt(n):
    if n < 0:
        return -integer_cbrt(-n)
    if n == 0:
        return 0
    low = 1
    high = 1 << ((n.bit_length() + 2) // 3)
    while low <= high:
        mid = (low + high) // 2
        if mid == 0: low = 1; continue
        mid_cubed = mid * mid * mid
        if mid_cubed == n: return mid
        elif mid_cubed < n: low = mid + 1
        else: high = mid - 1
    return high

def parse_output_file(filename="output.txt"):
    with open(filename, 'r') as f:
        content = f.read()
    matches = re.findall(r"n = (\d+)\s+e = 3\s+c = (\d+)", content)
    return [(int(n), int(c)) for n, c in matches]

def main():
    print("[-] 正在从 output.txt 解析加密数据...")
    crypto_data = parse_output_file()
    if len(crypto_data) < 3:
        print("[!] 数据不足，需要至少3组。")
        return

    print(f"[-] 成功解析到 {len(crypto_data)} 组数据。")
    print("[-] 开始遍历所有组合，寻找所有数学上可能的候选消息...")
    
    found_candidates = 0
    
    # enumerate 可以让我们知道这是第几个组合
    for i, combo in enumerate(itertools.combinations(crypto_data, 3)):
        moduli = [data[0] for data in combo]
        remainders = [data[1] for data in combo]

        try:
            m_cubed = solve_crt(remainders, moduli)
            m = integer_cbrt(m_cubed)
            
            # 这是最关键的硬性检查：结果必须是完美的立方数
            if m*m*m == m_cubed:
                found_candidates += 1
                message = long_to_bytes(m)
                
                print(f"\n--- 找到一个候选答案 (来自组合 #{i+1}) ---")
                print(f"  Raw Bytes: {message}")

                try:
                    decoded_utf8 = message.decode('utf-8')
                    print(f"  Decoded (UTF-8): {decoded_utf8}")
                except UnicodeDecodeError as e:
                    print(f"  Decoded (UTF-8): 失败 - {e}")
                
                # Latin-1 编码总能成功，可以让我们看到所有字节的字符表示
                decoded_latin1 = message.decode('latin-1')
                print(f"  Decoded (Latin-1): {decoded_latin1}")
                print("-----------------------------------------")

        except Exception:
            continue
    
    if found_candidates == 0:
        print("\n[!] 遍历了所有组合，但未能找到任何一个完美的立方数解。这很奇怪，请检查 output.txt 文件或脚本。")
    else:
        print(f"\n[+] 完成！共找到 {found_candidates} 个候选答案。请在上面的人工检查哪一个是真正的消息。")


if __name__ == "__main__":
    main()