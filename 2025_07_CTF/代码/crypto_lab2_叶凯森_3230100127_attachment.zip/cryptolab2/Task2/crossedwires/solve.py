from Crypto.Util.number import long_to_bytes, inverse
import math
import random
import ast # 用于安全地解析字符串中的Python字面值

def parse_input(filename="output.txt"):
    """从文件中解析 N, d, e, 朋友的公钥和密文"""
    with open(filename, 'r') as f:
        lines = f.readlines()

    # 解析私钥 (N, d)
    private_key_str = lines[0].split('My private key: ')[1].strip()
    N, d = ast.literal_eval(private_key_str)

    # 解析朋友的公钥
    friend_keys_str = lines[1].split("My Friend's public keys: ")[1].strip()
    friend_keys_list = ast.literal_eval(friend_keys_str)
    friend_keys_e = [key[1] for key in friend_keys_list]

    # 解析加密的flag
    cipher_str = lines[2].split('Encrypted flag: ')[1].strip()
    cipher = int(cipher_str)
    
    # 固定的公钥 e
    e = 0x10001
    
    return N, d, e, friend_keys_e, cipher

def factor_N_from_d(N, e, d):
    """利用已知的 e, d, N 来分解 N"""
    k = e * d - 1
    r = k
    s = 0
    while r % 2 == 0:
        r //= 2
        s += 1
    
    while True:
        a = random.randint(2, N - 2)
        x = pow(a, r, N)
        if x == 1 or x == N - 1:
            continue
            
        y = 0
        for _ in range(s):
            y = pow(x, 2, N)
            if y == 1:
                p = math.gcd(x - 1, N)
                q = N // p
                return p, q
            if y == N - 1:
                break
            x = y
        if y == N - 1:
            continue

# --- 主程序 ---
# 步骤 0: 从文件读取数据
print("正在从 output.txt 读取数据...")
N, d, e, friend_keys_e, cipher = parse_input()
print("数据读取成功！")

# 步骤 1: 分解 N 得到 p 和 q
print("正在分解 N ...")
p, q = factor_N_from_d(N, e, d)
print("分解成功！")

# 步骤 2: 计算 phi(N)
phi = (p - 1) * (q - 1)

# 步骤 3: 计算总的加密指数 E_total
E_total = 1
for friend_e in friend_keys_e:
    E_total *= friend_e

# 步骤 4: 计算总的解密密钥 D_total
D_total = inverse(E_total, phi)

# 步骤 5: 解密密文
decrypted_message = pow(cipher, D_total, N)

# 步骤 6: 将结果转换为字节
flag = long_to_bytes(decrypted_message)

print("\n解密成功！")
print(f"Flag: {flag.decode()}")