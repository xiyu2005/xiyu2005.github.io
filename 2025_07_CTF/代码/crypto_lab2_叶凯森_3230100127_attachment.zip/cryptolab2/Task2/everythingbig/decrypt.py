#!/usr/bin/env python3

from Crypto.Util.number import long_to_bytes

def wiener_attack(e, N, c):
    """
    执行维纳攻击来找到 RSA 私钥 d 并解密。
    e/N 的连分数收敛项之一是 k/d。
    """
    
    # 使用迭代方法计算 e/N 的连分数收敛项 p_n/q_n
    # p_n/q_n 在这里对应 k/d
    
    # 初始化 p 和 q 的前两项
    # p_{-2}=0, p_{-1}=1
    # q_{-2}=1, q_{-1}=0
    p_prev, q_prev = 0, 1
    p_curr, q_curr = 1, 0

    num, den = e, N
    
    print("开始进行维纳攻击...")
    iteration = 0
    while den != 0:
        iteration += 1
        
        # 计算连分数系数 a
        a = num // den
        
        # 计算下一个收敛项的分子和分母 (p_n, q_n)
        p_next = a * p_curr + p_prev
        q_next = a * q_curr + q_prev

        # 候选的 k 和 d
        # 注意：第一个收敛项 p_0/q_0 (k/d) 可能为 0/1 或 1/0，需要跳过无效情况
        k = p_next
        d = q_next

        # 更新 p 和 q 的值以进行下一次迭代
        p_prev, q_prev = p_curr, q_curr
        p_curr, q_curr = p_next, q_next

        # 更新连分数展开的余项
        num, den = den, num % den

        # d 不能为 0，且根据 RSA 定义，d 必须是奇数
        if d == 0 or d % 2 == 0:
            continue
        
        print(f"第 {iteration} 轮尝试: 候选 d = {hex(d)}")

        # 尝试用候选的 d 进行解密
        m_candidate = pow(c, d, N)
        
        try:
            # 将解密出的数字转换为字节
            flag = long_to_bytes(m_candidate)
            # 检查是否是我们寻找的 flag 格式
            if b'crypto{' in flag:
                print("\n成功找到 Flag!")
                return flag.decode('utf-8')
        except (ValueError, OverflowError):
            # 如果 m_candidate 无法正常转换为字节，则继续尝试下一个
            continue
            
    print("\n攻击失败，未找到有效的 d。")
    return None

def main():
    # 从 output.txt 文件中读取 N, e, c
    try:
        with open('output.txt', 'r') as f:
            lines = f.readlines()
            N = int(lines[0].split(' = ')[1], 16)
            e = int(lines[1].split(' = ')[1], 16)
            c = int(lines[2].split(' = ')[1], 16)
    except FileNotFoundError:
        print("错误: output.txt 文件未找到。")
        return
    except (IndexError, ValueError):
        print("错误: output.txt 文件格式不正确。")
        return

    # 执行攻击
    flag = wiener_attack(e, N, c)

    if flag:
        print(f"解密后的 Flag 是: {flag}")

if __name__ == '__main__':
    main()