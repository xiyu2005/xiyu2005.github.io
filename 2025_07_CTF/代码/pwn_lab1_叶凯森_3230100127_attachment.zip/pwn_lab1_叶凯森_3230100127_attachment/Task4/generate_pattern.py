# generate_pattern.py
from pwn import *
# 生成一个200字节长的、内容不重复的字符串
pattern = cyclic(200)
print(pattern.decode())