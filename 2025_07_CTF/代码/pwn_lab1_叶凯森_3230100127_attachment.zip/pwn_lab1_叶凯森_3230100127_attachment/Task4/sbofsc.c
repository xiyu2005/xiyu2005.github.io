// gcc sbofsc.c -fno-stack-protector -g -o sbofsc
#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <errno.h>

#define RDNKEY "MRND"
#define MAP_ADDR 0x20000

void prepare()
{
	setvbuf(stdin, 0LL, 2, 0LL);
	setvbuf(stdout, 0LL, 2, 0LL);
	alarm(60);
}

int main(int argc, char *argv[])
{
	prepare(); // quite necessary
	
	int rndval;
	int size = sysconf(_SC_PAGESIZE);
	char *rndstr = getenv(RDNKEY);
	char buffer[32];

	sscanf(rndstr, "%d", &rndval);

	uint64_t map_addr = MAP_ADDR + ((rndval % 8) * 0x1000);
	mmap(map_addr, size, PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
	puts("what's your name: ");
	read(0, map_addr, 64);
	puts("try to overflow me~");
	gets(buffer);
	return 0;
}
