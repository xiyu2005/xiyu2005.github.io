	.arch armv8-a
	.file	"or.c"
	.text
	.align	2
	.p2align 5,,15
	.global	bit_or
	.type	bit_or, %function
bit_or:
.LFB0:
	.cfi_startproc
	orr	w0, w0, w1
	ret
	.cfi_endproc
.LFE0:
	.size	bit_or, .-bit_or
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
