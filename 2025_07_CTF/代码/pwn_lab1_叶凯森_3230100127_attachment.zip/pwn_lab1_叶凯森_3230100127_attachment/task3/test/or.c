int bit_or(int a, int b)
{
    return a | b;
}