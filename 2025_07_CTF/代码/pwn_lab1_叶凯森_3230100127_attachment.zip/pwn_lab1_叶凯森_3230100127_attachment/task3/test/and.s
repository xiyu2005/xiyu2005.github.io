	.arch armv8-a
	.file	"and.c"
	.text
	.align	2
	.p2align 5,,15
	.global	bit_and
	.type	bit_and, %function
bit_and:
.LFB0:
	.cfi_startproc
	and	w0, w0, w1
	ret
	.cfi_endproc
.LFE0:
	.size	bit_and, .-bit_and
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
