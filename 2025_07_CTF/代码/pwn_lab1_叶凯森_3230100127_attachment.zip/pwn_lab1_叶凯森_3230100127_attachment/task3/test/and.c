int bit_and(int a, int b)
{
    return a & b;
}