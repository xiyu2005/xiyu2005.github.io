	.arch armv8-a
	.file	"add.c"
	.text
	.align	2
	.p2align 5,,15
	.global	add
	.type	add, %function
add:
.LFB0:
	.cfi_startproc
	add	w0, w0, w1
	ret
	.cfi_endproc
.LFE0:
	.size	add, .-add
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
