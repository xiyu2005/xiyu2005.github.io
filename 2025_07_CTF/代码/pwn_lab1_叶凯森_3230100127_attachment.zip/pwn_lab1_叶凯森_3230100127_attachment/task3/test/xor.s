	.arch armv8-a
	.file	"xor.c"
	.text
	.align	2
	.p2align 5,,15
	.global	bit_xor
	.type	bit_xor, %function
bit_xor:
.LFB0:
	.cfi_startproc
	eor	w0, w0, w1
	ret
	.cfi_endproc
.LFE0:
	.size	bit_xor, .-bit_xor
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
