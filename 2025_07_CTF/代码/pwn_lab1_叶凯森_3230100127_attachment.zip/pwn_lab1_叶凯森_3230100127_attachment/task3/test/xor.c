int bit_xor(int a, int b)
{
    return a ^ b;
}