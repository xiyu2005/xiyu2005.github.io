	.arch armv8-a
	.file	"sub.c"
	.text
	.align	2
	.p2align 5,,15
	.global	sub
	.type	sub, %function
sub:
.LFB0:
	.cfi_startproc
	sub	w0, w0, w1
	ret
	.cfi_endproc
.LFE0:
	.size	sub, .-sub
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
