#include <stdio.h>

int main()
{
	int i;
	char c;

	printf("Melody: Mom, I want a shell\n");
	printf("Mom: This machine will run your input as assemble instruction\n");
	fflush(NULL);
	char shellcode[35];
	read(0, shellcode, 35);
	(*(void (*)()) shellcode)();
}
